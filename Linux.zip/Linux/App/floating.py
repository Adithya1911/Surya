import gi
import subprocess
import os
import time
from gi.repository import Gtk, GLib
import signal
gi.require_version('Gtk', '3.0')
import shutil
class SLAMAppdebug_float(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Digital Heritage - Debugger")
        self.set_default_size(1000, 800)
        self.maximize()  # Maximize the window
        self.set_keep_above(True)  # Keep the app window on top

        # Create a Paned layout for the main sections
        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)

        # Fixed button area width
        self.fixed_button_width = 200

        # Create a box for buttons on the right side
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)  # Fixed width
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)

        # Buttons
        self.start_button = Gtk.Button(label="Start")
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        # Placeholder for SLAM Map Viewer
        self.slam_label = Gtk.Label(label="The SLAM Map Viewer will open in a separate window.")
        self.main_paned.pack1(self.slam_label, resize=True, shrink=True)

        # SLAM process management
        self.slam_process = None
        self.viewer_window_id = None
        self.app_window_position = None

        # Periodic check for resizing the Map Viewer
        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)

        # Ensure no previous SLAM process is running
        if self.slam_process:
            self.slam_process.terminate()
            self.slam_process = None

        # Start SLAM process
        #########################################
        Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
        Command = "./test_webcam_2.sh"
        #########################################
        slam_script = "/home/parthasaradhi-n/Desktop/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/mono_kitti.sh"
        env = os.environ.copy()
        env["DISPLAY"] = ":0"  # Ensure correct display for the SLAM process

        try:
            ############################################################################
            # self.slam_process = subprocess.Popen(slam_script, shell=True, env=env)
            # print("SLAM process started successfully. Map Viewer should appear shortly.")
            ############################################################################
            env = os.environ.copy()
            env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
            self.process = subprocess.Popen(
            Command, shell=True, env=env, cwd=Directory)
            # Wait for the viewer window to open
            time.sleep(5)  # Give it a few seconds to open
            self.move_window()
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)

    def move_window(self):
        try:
            # Use wmctrl to list all windows
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:  # Match by name
                    window_id = window.split()[0]
                    self.viewer_window_id = window_id
                    print(f"Found Map Viewer window: {window_id}")
                    self.resize_and_position_viewer()
                    return
            print("Map Viewer window not found.")
        except Exception as e:
            print(f"Error moving window: {e}")

    def resize_and_position_viewer(self):
        if self.viewer_window_id:
            # Get the size and position of the main app window
            app_x, app_y = self.get_position()
            width, height = self.get_size()

            # Calculate available space for the Map Viewer
            available_width = width - self.fixed_button_width
            available_height = height-37
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:  # Match window by name
                    # Extract the window ID
                    window_id = window.split()[0]
                    # subprocess.run(['wmctrl', '-i', '-r', window_id, '-b', 'remove,focus'])
                    print(f"Found window 'ORB-SLAM3: Map Viewer', resizing and moving it...")


            try:
                # Move and resize the Map Viewer window
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
                                '-e', f'0,{app_x},{app_y+37},{available_width},{available_height}'])
                print(f"Map Viewer resized to {available_width}x{available_height}.")
                # Bring the SLAM viewer window to the front (above the GTK window)
                subprocess.run(['wmctrl', '-i', '-a', window_id])  # Bring it to the front
               
            except Exception as e:
                print(f"Error resizing Map Viewer: {e}")

    def check_and_resize_map_viewer(self):
        if self.viewer_window_id:
            self.resize_and_position_viewer()
        return True  # Continue periodic checks

    def on_stop_clicked(self, widget):
        """Handler for Stop button."""
        if self.process is not None:
            try:
                # Send SIGINT (Ctrl+C) to the process group
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                self.process = None
                print("SLAM process stopped")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")
            finally:
                # Clear the folder
                folder_path = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data"
                try:
                    for item in os.listdir(folder_path):
                        item_path = os.path.join(folder_path, item)
                        if os.path.isfile(item_path) or os.path.islink(item_path):
                            os.unlink(item_path)  # Remove file or symbolic link
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)  # Remove directory
                    print(f"Folder '{folder_path}' has been cleared.")
                except Exception as e:
                    print(f"Failed to clear folder: {e}")

                # Re-enable buttons
                self.start_button.set_sensitive(True)
                self.stop_button.set_sensitive(False)

if __name__ == "__main__":
    app = SLAMAppdebug_float()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()