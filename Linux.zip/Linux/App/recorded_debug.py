# import gi
# from gi.repository import Gtk, Gdk
# import subprocess
# import os

# gi.require_version("Gtk", "3.0")


# class ScriptRunnerWindow(Gtk.Window):
#     def __init__(self):
#         super().__init__(title="Select Dataset")
#         self.set_default_size(600, 400)
#         self.set_border_width(20)
#         self.set_position(Gtk.WindowPosition.CENTER)  # Center the window on the screen

#         # Create a Frame to visually center and enclose the content
#         frame = Gtk.Frame()
#         # frame.set_label("Script Runner")  # Optional title for the frame
#         frame.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
#         self.add(frame)

#         # Main Box inside the frame
#         main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20, margin=20)
#         frame.add(main_box)

#         # Title Section
#         # title_label = Gtk.Label(label="Dataset and Script Runner")
#         # title_label.set_halign(Gtk.Align.CENTER)
#         # title_label.get_style_context().add_class("title")
#         # main_box.pack_start(title_label, False, False, 0)

#         # Folder Selection Section
#         folder_label = Gtk.Label(label="Please select a folder:")
#         folder_label.set_halign(Gtk.Align.CENTER)
#         main_box.pack_start(folder_label, False, False, 0)

#         self.select_folder_button = Gtk.Button(label="Select Dataset Folder")
#         self.select_folder_button.set_halign(Gtk.Align.CENTER)
#         self.select_folder_button.connect("clicked", self.on_select_folder)
#         main_box.pack_start(self.select_folder_button, False, False, 0)

#         self.folder_label = Gtk.Label(label="No folder selected")
#         self.folder_label.set_halign(Gtk.Align.CENTER)
#         main_box.pack_start(self.folder_label, False, False, 0)

#         # Script Selection Section
#         self.select_script_button = Gtk.Button(label="Select Script File")
#         self.select_script_button.set_halign(Gtk.Align.CENTER)
#         self.select_script_button.connect("clicked", self.on_select_script)
#         main_box.pack_start(self.select_script_button, False, False, 0)

#         self.script_label = Gtk.Label(label="No script selected")
#         self.script_label.set_halign(Gtk.Align.CENTER)
#         main_box.pack_start(self.script_label, False, False, 0)

#         # Sequence Number Input Section
#         sequence_label = Gtk.Label(label="Enter Sequence Number (If Required)")
#         sequence_label.set_halign(Gtk.Align.CENTER)
#         main_box.pack_start(sequence_label, False, False, 0)

#         self.sequence_entry = Gtk.Entry()
#         self.sequence_entry.set_halign(Gtk.Align.CENTER)
#         main_box.pack_start(self.sequence_entry, False, False, 0)

#         # Run Script Button
#         self.run_script_button = Gtk.Button(label="Run Script")
#         self.run_script_button.set_halign(Gtk.Align.CENTER)
#         self.run_script_button.connect("clicked", self.on_run_script)
#         main_box.pack_start(self.run_script_button, False, False, 0)

#         # Initialize variables
#         self.selected_folder = None
#         self.selected_script = None

#     def on_select_folder(self, widget):
#         dialog = Gtk.FileChooserDialog(
#             "Select a Dataset Folder",
#             self,
#             Gtk.FileChooserAction.SELECT_FOLDER,
#             ("Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK),
#         )

#         response = dialog.run()
#         if response == Gtk.ResponseType.OK:
#             self.selected_folder = dialog.get_filename()
#             self.folder_label.set_text(f"Selected Folder: {self.selected_folder}")
#         else:
#             self.folder_label.set_text("No folder selected")

#         dialog.destroy()

#     def on_select_script(self, widget):
#         dialog = Gtk.FileChooserDialog(
#             "Select a Script File",
#             self,
#             Gtk.FileChooserAction.OPEN,
#             ("Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK),
#         )

#         response = dialog.run()
#         if response == Gtk.ResponseType.OK:
#             self.selected_script = os.path.basename(dialog.get_filename())
#             self.script_label.set_text(f"Selected Script: {self.selected_script}")
#         else:
#             self.script_label.set_text("No script selected")

#         dialog.destroy()

#     def on_run_script(self, widget):
#         # sequence_number = self.sequence_entry.get_text()
#         # if self.selected_folder and self.selected_script and sequence_number:
#         #     command = f"{self.selected_script} {sequence_number}"
#         #     try:
#         #         process = subprocess.Popen(
#         #             command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
#         #         )
#         #         stdout, stderr = process.communicate()
#         #         print(f"Script output: {stdout.decode()}")
#         #         if stderr:
#         #             print(f"Script error: {stderr.decode()}")
#         #     except Exception as e:
#         #         print(f"Error running script: {e}")
#         # else:
#         #     print("Please select a folder, script, and enter a sequence number.")
#         sequence_number = self.sequence_entry.get_text()
#         if self.selected_folder and self.selected_script and sequence_number:
#             script_folder = f"{self.selected_folder}/"

#             script_seq= f"./{self.selected_script} {sequence_number}"
#             try:
#                 from admin import CombinedApp
#                 app=CombinedApp(script_folder,script_seq)
#                 app.show_all()

#             except Exception as e:
#                 print(f"Error running script: {e}")
#         else:
#             print("Please select a folder, script, and enter a sequence number.")
        
# # Run the application
# if __name__ == "__main__":
#     win = ScriptRunnerWindow()
#     win.connect("destroy", Gtk.main_quit)
#     win.show_all()
#     Gtk.main()
import gi
from gi.repository import Gtk, Gdk
import subprocess
import os
from location_debug import LocationPage
gi.require_version("Gtk", "3.0")


class ScriptRunnerWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Select Map")
        self.maximize()
        self.set_titlebar(self.create_header_bar())

        self.set_border_width(20)
        self.set_position(Gtk.WindowPosition.CENTER)  # Center the window on the screen

        # Create a Frame to visually center and enclose the content
        frame = Gtk.Frame()
        # frame.set_label("Script Runner")  # Optional title for the frame
        frame.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        self.add(frame)

        # Main Box inside the frame
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20, margin=20)
        frame.add(main_box)

        # Title Section
        # title_label = Gtk.Label(label="Dataset and Script Runner")
        # title_label.set_halign(Gtk.Align.CENTER)
        # title_label.get_style_context().add_class("title")
        # main_box.pack_start(title_label, False, False, 0)

        # # Folder Selection Section
        # folder_label = Gtk.Label(label="Please select a folder:")
        # folder_label.set_halign(Gtk.Align.CENTER)
        # main_box.pack_start(folder_label, False, False, 0)

        # self.select_folder_button = Gtk.Button(label="Select Dataset Folder")
        # self.select_folder_button.set_halign(Gtk.Align.CENTER)
        # self.select_folder_button.connect("clicked", self.on_select_folder)
        # main_box.pack_start(self.select_folder_button, False, False, 0)

        # self.folder_label = Gtk.Label(label="No folder selected")
        # self.folder_label.set_halign(Gtk.Align.CENTER)
        # main_box.pack_start(self.folder_label, False, False, 0)

        # Script Selection Section
        self.select_script_button = Gtk.Button(label="Select Map")
        self.select_script_button.set_halign(Gtk.Align.CENTER)
        self.select_script_button.connect("clicked", self.on_select_script)
        main_box.pack_start(self.select_script_button, False, False, 0)

        self.script_label = Gtk.Label(label="No Map selected")
        self.script_label.set_halign(Gtk.Align.CENTER)
        main_box.pack_start(self.script_label, False, False, 0)

        # # Sequence Number Input Section
        # sequence_label = Gtk.Label(label="Enter Sequence Number (If Required)")
        # sequence_label.set_halign(Gtk.Align.CENTER)
        # main_box.pack_start(sequence_label, False, False, 0)

        # self.sequence_entry = Gtk.Entry()
        # self.sequence_entry.set_halign(Gtk.Align.CENTER)
        # main_box.pack_start(self.sequence_entry, False, False, 0)

        # Run Script Button
        self.run_script_button = Gtk.Button(label="Load Map")
        self.run_script_button.set_halign(Gtk.Align.CENTER)
        self.run_script_button.connect("clicked", self.on_run_script)
        main_box.pack_start(self.run_script_button, False, False, 0)

        # Initialize variables
        self.selected_folder = None
        self.selected_script = None

    # def on_select_folder(self, widget):
        # dialog = Gtk.FileChooserDialog(
        #     "Select a Dataset Folder",
        #     self,
        #     Gtk.FileChooserAction.SELECT_FOLDER,
        #     ("Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK),
        # )

        # response = dialog.run()
        # if response == Gtk.ResponseType.OK:
        #     self.selected_folder = dialog.get_filename()
        #     self.folder_label.set_text(f"Selected Folder: {self.selected_folder}")
        # else:
        #     self.folder_label.set_text("No folder selected")

        # dialog.destroy()

    def on_select_script(self, widget):
        dialog = Gtk.FileChooserDialog(
            "Select a Map File",
            self,
            Gtk.FileChooserAction.OPEN,
            ("Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK),
        )

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.selected_script = os.path.basename(dialog.get_filename())
            self.script_label.set_text(f"Selected Map: {self.selected_script}")
        else:
            self.script_label.set_text("No Map selected")

        dialog.destroy()
    def create_header_bar(self):
        """Creates a custom header bar with a Back button."""
        header_bar = Gtk.HeaderBar(title="Load Map")
        header_bar.set_show_close_button(True)

        # Create Back Button
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)

        # Add the back button to the left side of the header
        header_bar.pack_start(back_button)
        
        return header_bar

    def on_back_button_clicked(self, widget):
        """Handle the back button click event."""
        app = LocationPage()
        app.show_all()
        self.hide()
        print("Back button clicked")
        # Add your back action here, like navigating to a previous screen.


    def on_run_script(self, widget):
        # sequence_number = self.sequence_entry.get_text()
        # if self.selected_folder and self.selected_script and sequence_number:
        #     command = f"{self.selected_script} {sequence_number}"
        #     try:
        #         process = subprocess.Popen(
        #             command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        #         )
        #         stdout, stderr = process.communicate()
        #         print(f"Script output: {stdout.decode()}")
        #         if stderr:
        #             print(f"Script error: {stderr.decode()}")
        #     except Exception as e:
        #         print(f"Error running script: {e}")
        # else:
        #     print("Please select a folder, script, and enter a sequence number.")


        # sequence_number = self.sequence_entry.get_text()
        # if self.selected_folder and self.selected_script and sequence_number:
        #     script_folder = f"{self.selected_folder}/"

        #     script_seq= f"./{self.selected_script} {sequence_number}"
        #     try:
        #         from admin import CombinedApp
        #         app=CombinedApp(script_folder,script_seq)
        #         app.show_all()

        #     except Exception as e:
        #         print(f"Error running script: {e}")
        # else:
        #     print("Please select a folder, script, and enter a sequence number.")

        print("selected Map")
        
# Run the application
if __name__ == "__main__":
    win = ScriptRunnerWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()