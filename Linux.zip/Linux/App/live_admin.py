# import gi
# gi.require_version("Gtk", "3.0")
# from gi.repository import Gtk, Gdk
# from location_admin import LocationPage
# import os
# import subprocess
# import time
# import signal
# import shutil

# class LiveMapWindow(Gtk.Window):
#     def __init__(self):
#         super().__init__(title="New Map")
#         self.set_border_width(10)
#         self.maximize()  # Set window size
#         self.set_titlebar(self.create_header_bar())

#         # Main layout container (horizontal layout)
#         main_layout = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
#         self.add(main_layout)

#         # Left section for buttons (Start and Stop)
#         button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         button_box.set_halign(Gtk.Align.START)

#         start_button = Gtk.Button(label="Start")
#         stop_button = Gtk.Button(label="Stop")
        
#         # Connect button actions
#         start_button.connect("clicked", self.on_start_clicked)
#         stop_button.connect("clicked", self.on_stop_clicked)

#         # Add buttons to button box
#         button_box.pack_start(start_button, False, False, 0)
#         button_box.pack_start(stop_button, False, False, 0)

#         # Right section for Live Map
#         live_map_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         live_map_box.set_halign(Gtk.Align.END)

#         # Create a visible box for the live map area inside a frame
#         self.live_map_area = Gtk.DrawingArea()
#         self.live_map_area.set_size_request(600, 400)  # Set the size of the map area

#         # Wrap the DrawingArea in a Frame to provide a border
#         frame = Gtk.Frame()
#         frame.set_border_width(2)
#         frame.add(self.live_map_area)  # Add the DrawingArea inside the Frame

#         # Add the frame (with the live map) to the live_map_box
#         live_map_box.pack_start(frame, True, True, 0)

#         # Add both sections to the main layout
#         main_layout.pack_start(button_box, False, False, 0)
#         main_layout.pack_start(live_map_box, True, True, 0)

    
    
#     def create_header_bar(self):
#         """Creates a custom header bar with a Back button."""
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)

#         # Create Back Button
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)

#         # Add the back button to the left side of the header
#         header_bar.pack_start(back_button)
        
#         return header_bar

   

#     def on_back_button_clicked(self, widget):
#         """Handle the back button click event."""
#         app = LocationPage()
#         app.show_all()
#         self.hide()
#         print("Back button clicked")
#         # Add your back action here, like navigating to a previous screen.


#     def on_start_clicked(self, button):
#         """Action for the Start button."""
#         Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/test_webcam_2.sh"
#         print("Start button clicked.")
#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"
#         try:
#             self.process = subprocess.Popen(
#                 [Directory],
#                 shell=True,
#                 env=env,
#                 cwd=os.path.dirname(Directory),
#                 preexec_fn=os.setsid
#             )
#         except Exception as e:
#             print(f"Error starting SLAM process: {e}")
#         # Implement your logic for starting the live map or related functionality

#     def on_stop_clicked(self, button):
#         """Action for the Stop button."""
#         print("Stop button clicked.")
#         Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
#         if self.process is not None:
#             try:
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
#                 self.process = None
#                 print("SLAM process stopped")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")
#             finally:
#                 try:
#                     for item in os.listdir(Frame_Dir):
#                         item_path = os.path.join(Frame_Dir, item)
#                         if os.path.isfile(item_path) or os.path.islink(item_path):
#                             os.unlink(item_path)
#                         elif os.path.isdir(item_path):
#                             shutil.rmtree(item_path)
#                     print(f"Folder '{Frame_Dir}' has been cleared.")
#                 except Exception as e:
#                     print(f"Failed to clear folder: {e}")

#         # Implement your logic for stopping the live map or related functionality


# # Run the app
# if __name__ == "__main__":
#     win = LiveMapWindow()
#     win.connect("destroy", Gtk.main_quit)
#     win.show_all()
#     Gtk.main()
import gi
import subprocess
import os
import time
from gi.repository import Gtk, GLib
from location_admin import LocationPage
import signal
gi.require_version('Gtk', '3.0')
import shutil
class LiveMapWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Digital Heritage - Admin")
        self.set_default_size(1000, 800)
        self.maximize()  # Maximize the window
        self.set_titlebar(self.create_header_bar())

        # self.set_keep_above(True)  # Keep the app window on top

        # Create a Paned layout for the main sections
        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)

        # Fixed button area width
        self.fixed_button_width = 200

        # Create a box for buttons on the right side
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)  # Fixed width
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)

        # Buttons
        self.start_button = Gtk.Button(label="Start")
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        # Placeholder for SLAM Map Viewer
        self.slam_label = Gtk.Label(label="The SLAM Map Viewer will open in a separate window.")
        self.main_paned.pack1(self.slam_label, resize=True, shrink=True)

        # SLAM process management
        self.slam_process = None
        self.viewer_window_id = None
        self.app_window_position = None

        # Periodic check for resizing the Map Viewer
        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)

        # Ensure no previous SLAM process is running
        if self.slam_process:
            self.slam_process.terminate()
            self.slam_process = None

        # Start SLAM process
        #########################################
        # Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
        Command = "./test_webcam_2.sh"
        #########################################
        # Get the absolute path of the script's directory
        CURRENT_DIR = os.path.abspath(os.path.dirname(__file__))

        # Traverse up to the parent directory (e.g., two levels up)
        BASE_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "../../"))

        # Configuration
        Command = "./test_webcam_2.sh"
        Directory = os.path.join(BASE_DIR, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
        Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
        os.makedirs(Frame_Dir, exist_ok=True)  # Ensure the frame directory exists
        

        
        
        
        
        slam_script = "/home/parthasaradhi-n/Desktop/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/mono_kitti.sh"
        env = os.environ.copy()
        env["DISPLAY"] = ":0"  # Ensure correct display for the SLAM process

        try:
            ############################################################################
            # self.slam_process = subprocess.Popen(slam_script, shell=True, env=env)
            # print("SLAM process started successfully. Map Viewer should appear shortly.")
            ############################################################################
            env = os.environ.copy()
            env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
            self.process = subprocess.Popen(
            Command, shell=True, env=env, cwd=Directory)

            # Wait for the viewer window to open
            time.sleep(5)  # Give it a few seconds to open
            # self.move_window()
            for _ in range(10):
                time.sleep(1)
                if self.move_window():
                    break
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)


    def move_window(self):
        try:
            # Use wmctrl to list all windows
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:  # Match by name
                    window_id = window.split()[0]
                    self.viewer_window_id = window_id
                    print(f"Found Map Viewer window: {window_id}")

                    # Remove decorations (header bar, borders, etc.)
                    subprocess.run(['xprop', '-id', window_id, '-f', '_MOTIF_WM_HINTS', '32c',
                                    '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])

                    # Resize and position the Map Viewer
                    self.resize_and_position_viewer()
                    return
            print("Map Viewer window not found.")
        except Exception as e:
            print(f"Error moving window: {e}")

    def resize_and_position_viewer(self):
        if self.viewer_window_id:
            # Get the size and position of the main app window
            app_x, app_y = self.get_position()
            width, height = self.get_size()

            # Calculate available space for the Map Viewer
            available_width = width - self.fixed_button_width
            available_height = height 

            try:
                # Move and resize the Map Viewer window
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
                                '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'])
                print(f"Map Viewer resized to {available_width}x{available_height}.")
            except Exception as e:
                print(f"Error resizing Map Viewer: {e}")

    # def move_window(self):
    #     try:
    #         # Use wmctrl to list all windows
    #         result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
    #         windows = result.stdout.splitlines()
    #         for window in windows:
    #             if "ORB-SLAM3: Map Viewer" in window:  # Match by name
    #                 window_id = window.split()[0]
    #                 self.viewer_window_id = window_id
    #                 print(f"Found Map Viewer window: {window_id}")
    #                 self.resize_and_position_viewer()
    #                 return
    #         print("Map Viewer window not found.")
    #     except Exception as e:
    #         print(f"Error moving window: {e}")
    def create_header_bar(self):
        """Creates a custom header bar with a Back button."""
        header_bar = Gtk.HeaderBar(title="Add New Map")
        header_bar.set_show_close_button(True)

        # Create Back Button
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)

        # Add the back button to the left side of the header
        header_bar.pack_start(back_button)
        
        return header_bar

   

    def on_back_button_clicked(self, widget):
        """Handle the back button click event."""
        app = LocationPage()
        app.show_all()
        self.hide()
        print("Back button clicked")
        # Add your back action here, like navigating to a previous screen.



    # def resize_and_position_viewer(self):
    #     if self.viewer_window_id:
    #         # Get the size and position of the main app window
    #         app_x, app_y = self.get_position()
    #         width, height = self.get_size()

    #         # Calculate available space for the Map Viewer
    #         available_width = width - self.fixed_button_width
    #         available_height = height-37
    #         result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
    #         windows = result.stdout.splitlines()
    #         for window in windows:
    #             if "ORB-SLAM3: Map Viewer" in window:  # Match window by name
    #                 # Extract the window ID
    #                 window_id = window.split()[0]
    #                 # subprocess.run(['wmctrl', '-i', '-r', window_id, '-b', 'remove,focus'])
    #                 print(f"Found window 'ORB-SLAM3: Map Viewer', resizing and moving it...")


    #         try:
    #             # Move and resize the Map Viewer window
    #             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
    #                             '-e', f'0,{app_x},{app_y+37},{available_width},{available_height}'])
    #             print(f"Map Viewer resized to {available_width}x{available_height}.")
    #             # Bring the SLAM viewer window to the front (above the GTK window)
    #             subprocess.run(['wmctrl', '-i', '-a', window_id])  # Bring it to the front
               
    #         except Exception as e:
    #             print(f"Error resizing Map Viewer: {e}")

    def check_and_resize_map_viewer(self):
        if self.viewer_window_id:
            self.resize_and_position_viewer()
        return True  # Continue periodic checks

    def on_stop_clicked(self, widget):
        """Handler for Stop button."""
        if self.process is not None:
            try:
                # Send SIGINT (Ctrl+C) to the process group
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                self.process = None
                print("SLAM process stopped")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")
            finally:
                # Clear the folder
                folder_path = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
                try:
                    for item in os.listdir(folder_path):
                        item_path = os.path.join(folder_path, item)
                        if os.path.isfile(item_path) or os.path.islink(item_path):
                            os.unlink(item_path)  # Remove file or symbolic link
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)  # Remove directory
                    print(f"Folder '{folder_path}' has been cleared.")
                except Exception as e:
                    print(f"Failed to clear folder: {e}")

                # Re-enable buttons
                self.start_button.set_sensitive(True)
                self.stop_button.set_sensitive(False)

if __name__ == "__main__":
    
        
    app = LiveMapWindow()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()