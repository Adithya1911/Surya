import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk,Gdk


class LinuxApp(Gtk.Window):
    def __init__(self):
        super().__init__(title="Digital Heritage")
        self.set_border_width(10)
        self.maximize()
        self.set_titlebar(self.create_header_bar())

        # Main layout container
        self.layout = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.layout.set_halign(Gtk.Align.CENTER)  # Center the whole layout container
        self.layout.set_valign(Gtk.Align.CENTER)  # Center the layout vertically
        self.add(self.layout)

        # Welcome title
        welcome_label = Gtk.Label(label="<span font='20' weight='bold'>Welcome to the Digital Heritage</span>")
        welcome_label.set_use_markup(True)
        welcome_label.set_halign(Gtk.Align.CENTER)
        self.layout.pack_start(welcome_label, False, False, 0)

        # Switch for Mode Switching (top-center)
        self.switch = Gtk.Switch()
        self.switch.set_size_request(60, 20)
        self.switch.set_active(False)  # Starts in Admin Mode
        self.switch.connect("state-set", self.on_switch_mode)

        # Switch Label Box
        switch_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        switch_box.set_halign(Gtk.Align.CENTER)  # Center horizontally
        switch_label = Gtk.Label(label="Debug Mode:")
        switch_box.pack_start(switch_label, False, False, 0)
        switch_box.pack_start(self.switch, False, False, 0)

        # Add the switch box to the layout
        self.layout.pack_start(switch_box, False, False, 0)

        # Stack for switching between Admin and Debug interfaces
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(500)

        # Admin Interface
        self.admin_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.admin_box.set_halign(Gtk.Align.CENTER)
        admin_button = Gtk.Button(label="Continue")
        admin_button.connect("clicked", self.on_admin_action)
        self.apply_button_style(admin_button)  # Apply hover effect style
        self.admin_box.pack_start(admin_button, False, False, 0)

        # Debug Interface
        self.debug_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.debug_box.set_halign(Gtk.Align.CENTER)
        debug_label = Gtk.Label(label="Debug Mode Interface")
        # self.debug_box.pack_start(debug_label, False, False, 0)

        # Add debug button below the label
        debug_button = Gtk.Button(label="Debug")
        debug_button.connect("clicked", self.on_debug_action)
        self.apply_button_style(debug_button)  # Apply hover effect style
        self.debug_box.pack_start(debug_button, False, False, 0)

        # Add interfaces to the stack
        self.stack.add_titled(self.admin_box, "admin", "Admin Interface")
        self.stack.add_titled(self.debug_box, "debug", "Debug Mode")

        # Add the stack below the switch
        self.layout.pack_start(self.stack, True, True, 0)

        # Apply CSS to buttons for hover effect
        self.apply_css()

    def apply_button_style(self, button):
        """Apply style to buttons with hover effect."""
        button.set_name("hover-button")

    def apply_css(self):
        """Apply custom CSS styles for hover effect."""
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
            .hover-button {
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                background-color: #4CAF50;
                color: white;
                border: none;
                transition: background-color 0.3s;
            }
            .hover-button:hover {
                background-color: #45a049;
            }
        """)
        style_context = self.get_style_context()
        style_context.add_provider(css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def create_header_bar(self):
        """Creates a custom header bar with a Back button."""
        header_bar = Gtk.HeaderBar(title="Digital Heritage")
        header_bar.set_show_close_button(True)

        # Create Back Button
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)

        # Add the back button to the left side of the header
        header_bar.pack_start(back_button)
        
        return header_bar

    def on_back_button_clicked(self, widget):
        """Handle the back button click event."""
        print("Back button clicked")
        # Add your back action here, like navigating to a previous screen.
    



    def apply_css(self):
        """Apply custom CSS styles for hover effect and toggle button."""
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
            .hover-button {
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                background-color: #4CAF50;
                color: white;
                border: none;
                transition: background-color 0.3s;
            }
            .hover-button:hover {
                background-color: #45a049;
            }
            .switch-on {
                background-color: green;
                color: white;
                
            }
        """)

        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def on_switch_mode(self, switch, state):
        """Switch between Admin and Debug modes and change switch background color."""
        if state:  # Debug Mode ON
            self.stack.set_visible_child_name("debug")
            self.switch.get_style_context().add_class("switch-on")
        else:  # Admin Mode
            self.stack.set_visible_child_name("admin")
            self.switch.get_style_context().remove_class("switch-on")

        return True  # Required for signal handling


    def on_admin_action(self, button):
        """Action for Admin Interface."""
     
        from location_admin import LocationPage
        app = LocationPage()
        app.show_all()
        self.hide()
        print("Admin action executed.")

    def on_debug_action(self, button):
        """Action for Debug Interface."""
      
        from location_debug import LocationPage
        app = LocationPage()
        app.show_all()
        self.hide()
        print("Debug action executed.")


# Run the app
if __name__ == "__main__":
    win = LinuxApp()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()