import gi
import os
import subprocess
import time
from gi.repository import Gtk, GdkPixbuf, GLib
import signal
import shutil
# Configuration
# Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
# Command = "./mono_kitti.sh 00"
Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data"
os.makedirs(Frame_Dir, exist_ok=True)  # Ensure the frame directory exists

class CombinedApp(Gtk.Window):

    def __init__(self,script_dir,script_command):
        super().__init__(title="Digital Heritage - Admin")
        self.Directory=script_dir
        self.Command=script_command
        self.set_default_size(800, 600)
        self.maximize()
        self.set_position(Gtk.WindowPosition.CENTER_ALWAYS)
        self.set_border_width(10)

        # Keep the window always on top
        self.set_keep_above(True)

        self.last_frame = None
        self.timeout = 5000  # Timeout in milliseconds
        self.last_update = time.time()
        self.process = None  # To store the process reference

        # Main container
        self.box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.add(self.box)

        # Buttons container
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_margin_top(10)
        self.button_box.set_margin_bottom(10)
        self.button_box.set_margin_start(10)
        self.button_box.set_margin_end(10)
        self.box.pack_start(self.button_box, False, True, 0)

        # Buttons
        self.button_start = Gtk.Button(label="Start")
        self.button_start.connect("clicked", self.start_clicked)
        self.button_box.pack_start(self.button_start, False, True, 0)

        self.button_stop = Gtk.Button(label="Stop")
        self.button_stop.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.button_stop, False, True, 0)

        # Video viewer container
        self.viewer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.viewer_box.set_halign(Gtk.Align.CENTER)
        self.viewer_box.set_valign(Gtk.Align.CENTER)
        self.box.pack_start(self.viewer_box, True, True, 0)

        # Video viewer components
        self.image = Gtk.Image()
        self.label = Gtk.Label(label="Waiting for frames...")
        self.viewer_box.pack_start(self.image, True, True, 0)
        self.viewer_box.pack_start(self.label, False, False, 0)

        # Start frame update loop
        GLib.timeout_add(30, self.update_frame)

    def start_clicked(self, widget):
        env = os.environ.copy()
        env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
        self.process = subprocess.Popen(
            self.Command, shell=True, env=env, cwd=self.Directory
        )

    def on_stop_clicked(self, widget):
        """Handler for Stop button."""
        if self.process is not None:
            try:
                # Send SIGINT (Ctrl+C) to the process group
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                self.process = None
                print("SLAM process stopped")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")
            finally:
                # Clear the folder
                folder_path = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data"
                try:
                    for item in os.listdir(folder_path):
                        item_path = os.path.join(folder_path, item)
                        if os.path.isfile(item_path) or os.path.islink(item_path):
                            os.unlink(item_path)  # Remove file or symbolic link
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)  # Remove directory
                    print(f"Folder '{folder_path}' has been cleared.")
                except Exception as e:
                    print(f"Failed to clear folder: {e}")

                # Re-enable buttons
                self.start_button.set_sensitive(True)
                self.stop_button.set_sensitive(False)


    def update_frame(self):
        # Find the latest frame
        frames = sorted([f for f in os.listdir(Frame_Dir) if f.endswith('.jpg')])
        if not frames:
            # Handle missing frames
            self.show_placeholder()
            return True

        latest_frame = frames[-1]
        if latest_frame == self.last_frame:
            # No new frame, show placeholder if timeout occurs
            if time.time() - self.last_update > self.timeout / 1000:
                self.show_placeholder()
            return True

        # Load and display the new frame
        frame_path = os.path.join(Frame_Dir, latest_frame)
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(frame_path)
            self.image.set_from_pixbuf(pixbuf)
            self.label.set_text("")  # Clear the placeholder text
            self.last_frame = latest_frame
            self.last_update = time.time()

            # Delete the frame after rendering
            os.remove(frame_path)
        except Exception as e:
            print(f"Error processing frame {frame_path}: {e}")

        return True

    def show_placeholder(self):
        self.label.set_text("Waiting for frames...")
        if self.last_frame is None:
            self.image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)

# Main application
if __name__ == "__main__":
    app = CombinedApp()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()