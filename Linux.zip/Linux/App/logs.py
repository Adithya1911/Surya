# import gi
# import subprocess
# import threading
# from gi.repository import Gtk, GLib
# # from live_debug import LiveMapWindow

# gi.require_version('Gtk', '3.0')

# LOG_FILE = "app_logs.txt"  # Read from the same log file as your main app

# class LogViewerWindow(Gtk.Window):
#     def __init__(self,live_debug_ref):
#         super().__init__(title="Logs")
#         self.maximize()
#         self.set_border_width(10)
#         # Keep the window always on top
    
#         self.live_debug=live_debug_ref
#         self.set_titlebar(self.create_header_bar())



#         # Create a TextView for logs
#         self.log_view = Gtk.TextView()
#         self.log_view.set_editable(False)
#         self.log_view.set_wrap_mode(Gtk.WrapMode.WORD)
#         self.log_buffer = self.log_view.get_buffer()

#         # Scrollable window for logs
#         self.scrolled_window = Gtk.ScrolledWindow()
#         self.scrolled_window.set_hexpand(True)
#         self.scrolled_window.set_vexpand(True)
#         self.scrolled_window.add(self.log_view)

#         # Add to window
#         self.add(self.scrolled_window)

#         # Start capturing logs
#         self.capture_logs()

#     def capture_logs(self):
#         """Captures both system and terminal logs and updates the log view."""
#         def run_log_capture():
#             process = subprocess.Popen(
#                 ['bash', '-c', f'tail -f {LOG_FILE} & journalctl -f'],
#                 stdout=subprocess.PIPE,
#                 stderr=subprocess.PIPE,
#                 text=True
#             )
#             while True:
#                 output = process.stdout.readline()
#                 if output:
#                     GLib.idle_add(self.update_log_view, output)
#                 if process.poll() is not None:
#                     break
        
#         log_thread = threading.Thread(target=run_log_capture, daemon=True)
#         log_thread.start()

    
#     def update_log_view(self, log_text):
#         """Appends new logs to the TextView."""
#         end_iter = self.log_buffer.get_end_iter()
#         self.log_buffer.insert(end_iter, log_text)
#         adj = self.scrolled_window.get_vadjustment()
#         adj.set_value(adj.get_upper())  # Auto-scroll to the bottom


#     def create_header_bar(self):
#         header_bar = Gtk.HeaderBar(title="Logs")
#         header_bar.set_show_close_button(True)
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)
#         header_bar.pack_start(back_button)
#         return header_bar

#     def on_back_button_clicked(self, widget):
#         self.live_debug.show_all()
#         self.hide()

# # Run the log viewer window
# if __name__ == "__main__":
#     app = LogViewerWindow()
#     app.connect("destroy", Gtk.main_quit)
#     app.show_all()
#     Gtk.main()
import gi
import os
import threading
import time
from gi.repository import Gtk, GLib

gi.require_version('Gtk', '3.0')

LOG_FILE = "live_debug_logs.txt"

class LogWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Logs")
        self.set_default_size(600, 400)
        self.set_titlebar(self.create_header_bar())
        self.maximize()
        self.textview = Gtk.TextView()
        self.textbuffer = self.textview.get_buffer()
        self.textview.set_editable(False)
        self.textview.set_wrap_mode(Gtk.WrapMode.WORD)

        self.scrolled_window = Gtk.ScrolledWindow()
        self.scrolled_window.set_vexpand(True)
        self.scrolled_window.add(self.textview)

        self.add(self.scrolled_window)

        self.load_existing_logs()
        self.start_log_reader()
        self.show_all()  # Ensure it is visible immediately

    def load_existing_logs(self):
        """Load previous logs from file."""
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = f.read()
                self.append_text(logs)

    def create_header_bar(self):
        """Create a header bar with a back button."""
        header_bar = Gtk.HeaderBar(title="Logs")
        header_bar.set_show_close_button(True)

        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)
        header_bar.pack_start(back_button)

        return header_bar

    def on_back_button_clicked(self, widget):
        """Hide the logs window when back is clicked."""
        self.hide()

    def start_log_reader(self):
        """Continuously reads new logs."""
        def read_logs():
            try:
                with open(LOG_FILE, "r", encoding="utf-8") as f:
                    f.seek(0, os.SEEK_END)
                    while True:
                        line = f.readline()
                        if line:
                            GLib.idle_add(self.append_text, line)
                        else:
                            time.sleep(0.1)  # Prevents CPU overuse
            except Exception as e:
                print(f"Error reading log file: {e}")

        threading.Thread(target=read_logs, daemon=True).start()

    def append_text(self, text):
        """Append text to the log buffer."""
        end_iter = self.textbuffer.get_end_iter()
        self.textbuffer.insert(end_iter, text + "\n")
        return False

#  **Run as a main standalone GTK window**
if __name__ == "__main__":
    win = LogWindow()
    win.connect("destroy", Gtk.main_quit)
    Gtk.main()