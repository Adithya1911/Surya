# import gi
# gi.require_version("Gtk", "3.0")
# from gi.repository import Gtk, Gdk
# from location_debug import LocationPage
# import os
# import subprocess
# import time
# import signal
# import shutil

# class LiveMapWindow(Gtk.Window):
#     def __init__(self):
#         super().__init__(title="New Map")
#         self.set_border_width(10)
#         self.maximize()  # Set window size
#         self.set_titlebar(self.create_header_bar())

#         # Main layout container (horizontal layout)
#         main_layout = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
#         self.add(main_layout)

#         # Left section for buttons (Start, Stop, Show Logs, Show Features)
#         button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         button_box.set_halign(Gtk.Align.START)

#         # Create buttons
#         start_button = Gtk.Button(label="Start")
#         stop_button = Gtk.Button(label="Stop")
#         show_logs_button = Gtk.Button(label="Show Logs")
#         show_features_button = Gtk.Button(label="Show Features")
        
#         # Connect button actions
#         start_button.connect("clicked", self.on_start_clicked)
#         stop_button.connect("clicked", self.on_stop_clicked)
#         show_logs_button.connect("clicked", self.on_show_logs_clicked)
#         show_features_button.connect("clicked", self.on_show_features_clicked)

#         # Add buttons to button box
#         button_box.pack_start(start_button, False, False, 0)
#         button_box.pack_start(stop_button, False, False, 0)
#         button_box.pack_start(show_logs_button, False, False, 0)
#         button_box.pack_start(show_features_button, False, False, 0)

#         # Right section for Live Map
#         live_map_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         live_map_box.set_halign(Gtk.Align.END)

#         # Create a visible box for the live map area inside a frame
#         self.live_map_area = Gtk.DrawingArea()
#         self.live_map_area.set_size_request(600, 400)  # Set the size of the map area

#         # Wrap the DrawingArea in a Frame to provide a border
#         frame = Gtk.Frame()
#         frame.set_border_width(2)
#         frame.add(self.live_map_area)  # Add the DrawingArea inside the Frame

#         # Add the frame (with the live map) to the live_map_box
#         live_map_box.pack_start(frame, True, True, 0)

#         # Add both sections to the main layout
#         main_layout.pack_start(button_box, False, False, 0)
#         main_layout.pack_start(live_map_box, True, True, 0)

    
#     def create_header_bar(self):
#         """Creates a custom header bar with a Back button."""
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)

#         # Create Back Button
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)

#         # Add the back button to the left side of the header
#         header_bar.pack_start(back_button)
        
#         return header_bar


#     def on_back_button_clicked(self, widget):
#         """Handle the back button click event."""
#         app = LocationPage()
#         app.show_all()
#         self.hide()
#         print("Back button clicked")
#         # Add your back action here, like navigating to a previous screen.


#     def on_start_clicked(self, widget):
#         self.start_button.set_sensitive(False)

#         # Ensure no previous SLAM process is running
#         if self.process:
#             self.process.terminate()
#             self.process = None

#         # Start SLAM process
#         #########################################
#         # Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
#         Command = "./test_webcam_2.sh"
#         #########################################
#         # Get the absolute path of the script's directory
#         CURRENT_DIR = os.path.abspath(os.path.dirname(__file__))

#         # Traverse up to the parent directory (e.g., two levels up)
#         BASE_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "../../"))

#         # Configuration
#         Command = "./test_webcam_2.sh"
#         Directory = os.path.join(BASE_DIR, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
#         Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
#         os.makedirs(Frame_Dir, exist_ok=True)  # Ensure the frame directory exists
        

        
        
        
        
#         slam_script = "/home/parthasaradhi-n/Desktop/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/mono_kitti.sh"
#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"  # Ensure correct display for the SLAM process

#         try:
#             ############################################################################
#             # self.process = subprocess.Popen(slam_script, shell=True, env=env)
#             # print("SLAM process started successfully. Map Viewer should appear shortly.")
#             ############################################################################
#             env = os.environ.copy()
#             env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
#             self.process = subprocess.Popen(
#             Command, shell=True, env=env, cwd=Directory)

#             # Wait for the viewer window to open
#             time.sleep(5)  # Give it a few seconds to open
#             # self.move_window()
#             for _ in range(10):
#                 time.sleep(1)
#                 if self.move_window():
#                     break
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)
#         # """Action for the Start button."""
#         # # Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/test_webcam_2.sh"
#         # Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
#         # Command = "./test_webcam_2.sh"
#         # env = os.environ.copy()
#         # env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
#         # self.process = subprocess.Popen(
#         #     Command, shell=True, env=env, cwd=Directory
#         # )
        
#         # print("Start button clicked.")
#         # # env = os.environ.copy()
#         # # env["DISPLAY"] = ":0"
#         # # try:
#         # #     self.process = subprocess.Popen(
#         # #         [Directory],
#         # #         shell=True,
#         # #         env=env,
#         # #         cwd=os.path.dirname(Directory),
#         # #         preexec_fn=os.setsid
#         # #     )
#         # # except Exception as e:
#         # #     print(f"Error starting SLAM process: {e}")
#         # # # Implement your logic for starting the live map or related functionality
#         # # print("Start button clicked.")
#         # # # Implement your logic for starting the live map or related functionality

#     def on_stop_clicked(self, button):
#         """Action for the Stop button."""
#         print("Stop button clicked.")
#         print("Stop button clicked.")
#         Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
#         if self.process is not None:
#             try:
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
#                 self.process = None
#                 print("SLAM process stopped")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")
#             finally:
#                 try:
#                     for item in os.listdir(Frame_Dir):
#                         item_path = os.path.join(Frame_Dir, item)
#                         if os.path.isfile(item_path) or os.path.islink(item_path):
#                             os.unlink(item_path)
#                         elif os.path.isdir(item_path):
#                             shutil.rmtree(item_path)
#                     print(f"Folder '{Frame_Dir}' has been cleared.")
#                 except Exception as e:
#                     print(f"Failed to clear folder: {e}")

#         # Implement your logic for stopping the live map or related functionality

#         # Implement your logic for stopping the live map or related functionality

#     def on_show_logs_clicked(self, button):
#         """Action for the Show Logs button."""
#         from logs import LogWindow
#         app=LogWindow()
#         app.show_all()
#         print("Show Logs button clicked.")
#         # Implement your logic for displaying logs or related functionality

#     def on_show_features_clicked(self, button):
#         """Action for the Show Features button."""
#         from features import Features
#         app=Features()
#         app.show_all()
        
#         print("Show Features button clicked.")
#         # Implement your logic for displaying features or related functionality


# # Run the app
# if __name__ == "__main__":
#     win = LiveMapWindow()
#     win.connect("destroy", Gtk.main_quit)
#     win.show_all()
#     Gtk.main()
# import gi
# gi.require_version("Gtk", "3.0")
# from gi.repository import Gtk, Gdk
# from location_debug import LocationPage
# import os
# import subprocess
# import time
# import signal
# import shutil


# class LiveMapWindow(Gtk.Window):
#     def __init__(self):
#         super().__init__(title="New Map")
#         self.set_border_width(10)
#         self.maximize()  # Set window size
#         self.set_titlebar(self.create_header_bar())

#         # Initialize SLAM process attribute
#         self.process = None

#         # Main layout container (horizontal layout)
#         main_layout = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
#         self.add(main_layout)

#         # Left section for buttons (Start, Stop, Show Logs, Show Features)
#         button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         button_box.set_halign(Gtk.Align.START)

#         # Create buttons
#         self.start_button = Gtk.Button(label="Start")
#         self.stop_button = Gtk.Button(label="Stop")
#         show_logs_button = Gtk.Button(label="Show Logs")
#         show_features_button = Gtk.Button(label="Show Features")

#         # Connect button actions
#         self.start_button.connect("clicked", self.on_start_clicked)
#         self.stop_button.connect("clicked", self.on_stop_clicked)
#         show_logs_button.connect("clicked", self.on_show_logs_clicked)
#         show_features_button.connect("clicked", self.on_show_features_clicked)

#         # Add buttons to button box
#         button_box.pack_start(self.start_button, False, False, 0)
#         button_box.pack_start(self.stop_button, False, False, 0)
#         button_box.pack_start(show_logs_button, False, False, 0)
#         button_box.pack_start(show_features_button, False, False, 0)

#         # Right section for Live Map
#         live_map_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         live_map_box.set_halign(Gtk.Align.END)

#         # Create a visible box for the live map area inside a frame
#         self.live_map_area = Gtk.DrawingArea()
#         self.live_map_area.set_size_request(600, 400)  # Set the size of the map area

#         # Wrap the DrawingArea in a Frame to provide a border
#         frame = Gtk.Frame()
#         frame.set_border_width(2)
#         frame.add(self.live_map_area)  # Add the DrawingArea inside the Frame

#         # Add the frame (with the live map) to the live_map_box
#         live_map_box.pack_start(frame, True, True, 0)

#         # Add both sections to the main layout
#         main_layout.pack_start(button_box, False, False, 0)
#         main_layout.pack_start(live_map_box, True, True, 0)

#     def create_header_bar(self):
#         """Creates a custom header bar with a Back button."""
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)

#         # Create Back Button
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)

#         # Add the back button to the left side of the header
#         header_bar.pack_start(back_button)

#         return header_bar

#     def on_back_button_clicked(self, widget):
#         """Handle the back button click event."""
#         app = LocationPage()
#         app.show_all()
#         self.hide()
#         print("Back button clicked")

#     def on_start_clicked(self, widget):
#         """Action for the Start button."""
#         self.start_button.set_sensitive(False)
#         self.stop_button.set_sensitive(True)

#         # Ensure no previous SLAM process is running
#         if self.process:
#             self.process.terminate()
#             self.process = None

#         # Start SLAM process
#         command = "./test_webcam_2.sh"
#         current_dir = os.path.abspath(os.path.dirname(__file__))
#         base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
#         directory = os.path.join(base_dir, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
#         frame_dir = os.path.join(base_dir, "Data/Features/")
#         os.makedirs(frame_dir, exist_ok=True)  # Ensure the frame directory exists

#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary

#         try:
#             self.process = subprocess.Popen(
#                 command, shell=True, env=env, cwd=directory
#             )
#             print("SLAM process started successfully. Map Viewer should appear shortly.")
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)

#     def on_stop_clicked(self, widget):
#         """Action for the Stop button."""
#         print("Stop button clicked.")
#         self.start_button.set_sensitive(True)
#         self.stop_button.set_sensitive(False)

#         frame_dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"

#         if self.process:
#             try:
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
#                 self.process = None
#                 print("SLAM process stopped.")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")

#             # Clear the frames directory
#             try:
#                 for item in os.listdir(frame_dir):
#                     item_path = os.path.join(frame_dir, item)
#                     if os.path.isfile(item_path) or os.path.islink(item_path):
#                         os.unlink(item_path)
#                     elif os.path.isdir(item_path):
#                         shutil.rmtree(item_path)
#                 print(f"Folder '{frame_dir}' has been cleared.")
#             except Exception as e:
#                 print(f"Failed to clear folder: {e}")

#     def on_show_logs_clicked(self, widget):
#         """Action for the Show Logs button."""
#         from logs import LogWindow
#         app = LogWindow()
#         app.show_all()
#         self.hide()
#         print("Show Logs button clicked.")

#     def on_show_features_clicked(self, widget):
#         """Action for the Show Features button."""
#         from features import Features
#         app = Features()
#         app.show_all()
#         self.hide()
#         print("Show Features button clicked.")


# # Run the app
# if __name__ == "__main__":
#     win = LiveMapWindow()
#     win.connect("destroy", Gtk.main_quit)
#     win.show_all()
#     Gtk.main()











#working
# import gi
# import subprocess
# import os
# import time
# from gi.repository import Gtk, GLib, Gdk
# from location_admin import LocationPage
# from logs import LogViewerApp
# import signal
# import shutil
# import threading
# import time

# gi.require_version('Gtk', '3.0')

# class LiveMapWindow(Gtk.Window):
#     def __init__(self):
#         Gtk.Window.__init__(self, title="Digital Heritage - Admin")
#         self.set_default_size(1000, 800)
#         self.maximize()
#         self.set_titlebar(self.create_header_bar())

#         self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
#         self.add(self.main_paned)

#         self.fixed_button_width = 200

#         self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         self.button_box.set_size_request(self.fixed_button_width, -1)
#         self.main_paned.pack2(self.button_box, resize=False, shrink=False)

#         self.start_button = Gtk.Button(label="Start")
#         self.start_button.connect("clicked", self.on_start_button_clicked)
#         self.button_box.pack_start(self.start_button, False, False, 0)

#         self.stop_button = Gtk.Button(label="Stop")
#         self.stop_button.connect("clicked", self.on_stop_clicked)
#         self.button_box.pack_start(self.stop_button, False, False, 0)

#         self.logs_button = Gtk.Button(label="Show logs")
#         self.logs_button.connect("clicked", self.on_show_logs_clicked)
#         self.button_box.pack_start(self.logs_button, False, False, 0)

#         self.features_button = Gtk.Button(label="Show features")
#         self.features_button.connect("clicked", self.on_show_features_clicked)
#         self.button_box.pack_start(self.features_button, False, False, 0)

#         self.map_area = Gtk.DrawingArea()
#         self.map_area.set_size_request(800, 600)
#         self.main_paned.pack1(self.map_area, resize=True, shrink=True)

#         self.process = None
#         self.viewer_window_id = None

#         # Inside the `__init__` method of `LiveMapWindow`
#         self.connect("focus-in-event", self.on_focus_in)
#         # self.connect("focus-out-event", self.on_focus_out)
#         # focus_thread = threading.Thread(target=self.monitor_focus, args=(self,), daemon=True)
#         # focus_thread.start()

#         # self.connect("window-state-event", self.on_window_state_event)
#         GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

#     def on_start_button_clicked(self, widget):
#         self.start_button.set_sensitive(False)


#         # Ensure no previous SLAM process is running
#         if self.process:
#             self.process.terminate()
#             self.process = None
        

#         # Start SLAM process
#         #########################################
#         # Directory = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/"
#         Command = "./test_webcam_2.sh"
#         #########################################
#         # Get the absolute path of the script's directory
#         CURRENT_DIR = os.path.abspath(os.path.dirname(__file__))

#         # Traverse up to the parent directory (e.g., two levels up)
#         BASE_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "../../"))

#         # Configuration
#         Command = "./test_webcam_2.sh"
#         Directory = os.path.join(BASE_DIR, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
#         Frame_Dir = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
#         os.makedirs(Frame_Dir, exist_ok=True)  # Ensure the frame directory exists
        

        
        
        
        
#         slam_script = "/home/parthasaradhi-n/Desktop/Digital-Heritage-main/ORB_SLAM3/Examples/Monocular/Run_Scripts/mono_kitti.sh"
#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"  # Ensure correct display for the SLAM process

#         try:
#             ############################################################################
#             # self.process = subprocess.Popen(slam_script, shell=True, env=env)
#             # print("SLAM process started successfully. Map Viewer should appear shortly.")
#             ############################################################################
#             env = os.environ.copy()
#             env["DISPLAY"] = ":0"  # Ensure GUI compatibility if necessary
#             self.process = subprocess.Popen(
#             Command, shell=True, env=env, cwd=Directory)

#             # Wait for the viewer window to open
#             time.sleep(5)  # Give it a few seconds to open
#             # self.move_window()
#             for _ in range(10):
#                 time.sleep(1)
#                 if self.move_window():
#                     break
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)


#     def update_map_viewer(self):
#         if self.process and self.process.poll() is None:
#             output = self.process.stdout.readline()
#             if output:
#                 self.update_map_area(output)
#             return True
#         return False

#     def update_map_area(self, data):
#         # Implement the logic to update the DrawingArea with SLAM data
#         pass

#     def on_window_state_event(self, widget, event):
#         if event.new_window_state & Gdk.WindowState.ICONIFIED:
#             print("Window minimized")
#             # Handle minimized state
#         elif event.new_window_state & Gdk.WindowState.MAXIMIZED:
#             print("Window maximized")
#             # Handle maximized state
#         else:
#             print("Window restored")
#             # Handle restored state
#         return True

#     def create_header_bar(self):
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)

#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)

#         header_bar.pack_start(back_button)
        
#         return header_bar

#     def on_back_button_clicked(self, widget):
#         app = LocationPage()
#         app.show_all()
#         self.hide()
#         print("Back button clicked")

#     def on_show_logs_clicked(self, widget):
#         from logs import LogViewerApp
#         app = LogViewerApp()
#         app.show_all()
#         print("Show Logs button clicked.")

#     def on_show_features_clicked(self, widget):
#         from features import Features
#         app = Features()
#         app.show_all()
#         self.hide()
#         print("Show Features button clicked.")

#     def move_window(self):
#         try:
#             # Use wmctrl to list all windows
#             result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
#             windows = result.stdout.splitlines()
#             for window in windows:
#                 if "ORB-SLAM3: Map Viewer" in window:  # Match by name
#                     window_id = window.split()[0]
#                     self.viewer_window_id = window_id
                
#                     print(f"Found Map Viewer window: {window_id}")

#                     # Remove decorations (header bar, borders, etc.)
#                     subprocess.run(['xprop', '-id', window_id, '-f', '_MOTIF_WM_HINTS', '32c',
#                                     '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])

#                     # Resize and position the Map Viewer
#                     self.resize_and_position_viewer()
#                     return
#             print("Map Viewer window not found.")
#         except Exception as e:
#             print(f"Error moving window: {e}")

#     def get_active_window(self):
#         """Returns the active window ID."""
#         try:
#             result = subprocess.run(['xdotool', 'getactivewindow'], capture_output=True, text=True)
#             return result.stdout.strip()
#         except Exception as e:
#             print(f"Error getting active window: {e}")
#             return None

#     def on_focus_in(self, widget, event):
#         """ Called when the GTK app gains focus. """
#         print("GTK App in Focus")
#         if self.viewer_window_id:
#             # Keep the Map Viewer always on top
#             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             self.resize_and_position_viewer()
    
#     def on_focus_out(self, widget, event):
#         """ Called when the GTK app loses focus. """
#         print("GTK App Lost Focus")
        
#         active_window = self.get_active_window()
        
#         # Only minimize if the new active window is NOT the Map Viewer
#         if active_window and active_window != self.viewer_window_id:
#             print(f"Minimizing Map Viewer window ID: {self.viewer_window_id}")
#             subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
#         else:
#             print("Focus moved to Map Viewer, not minimizing.")
        
#     # def monitor_focus(self):
#     #     """ Continuously checks the focused window and updates Map Viewer behavior accordingly. """
#     #     while True:
#     #         try:
#     #             # Get currently focused window name
#     #             focused_window = subprocess.run(['xdotool', 'getwindowfocus', 'getwindowname'], 
#     #                                             capture_output=True, text=True).stdout.strip()

#     #             if "Welcome to Digital Heritage" in focused_window:  # Your GTK app name
#     #                 print("GTK App in Focus - Bringing Map Viewer to Top")
#     #                 if self.viewer_window_id:
#     #                     subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])

#     #             elif "ORB-SLAM3: Map Viewer" in focused_window:  # Map Viewer is focused
#     #                 print("Map Viewer is Focused - Keeping It on Top")
#     #                 # Do nothing, prevent unnecessary minimization

#     #             else:  # Another app is focused
#     #                 print("Another App in Focus - Allowing Other Windows Above")
#     #                 if self.viewer_window_id:
#     #                     subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'remove,above'])

#     #         except Exception as e:
#     #             print(f"Error in focus monitoring: {e}")

#     #         time.sleep(1)  # Check focus every second



#     def resize_and_position_viewer(self):
#         """Resize and position the Map Viewer window."""
#         result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
#         windows = result.stdout.splitlines()
#         for window in windows:
#             if "ORB-SLAM3: Map Viewer" in window:  # Match by name
#                 window_id = window.split()[0]
#                 self.viewer_window_id = window_id

#         if self.viewer_window_id:
#             # Get the size and position of the main app window
#             app_x, app_y = self.get_position()
#             width, height = self.get_size()

#             # Calculate available space for the Map Viewer
#             available_width = width - self.fixed_button_width
#             available_height = height 

#             try:
#                 # Move and resize the Map Viewer window
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
#                                 '-e', f'0,{app_x},{app_y+45},{available_width},{available_height}'])
                
#                 # Keep the window always on top
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])

#                 print(f"Map Viewer resized to {available_width}x{available_height}.")
#             except Exception as e:
#                 print(f"Error resizing Map Viewer: {e}")




#     def check_and_resize_map_viewer(self):
#         if self.viewer_window_id:
#             self.resize_and_position_viewer()
#         return True
    

#     def close_map_viewer(self):
#         """ Force close the Map Viewer window. """
#         if self.viewer_window_id:
#             try:
#                 subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
#                 print("Map Viewer window closed.")
#             except Exception as e:
#                 print(f"Failed to close Map Viewer: {e}")

#     def on_stop_clicked(self, widget):
#         # """Handler for Stop button."""
#         # if self.process is not None:
#         #     try:
#         #         # Send SIGINT (Ctrl+C) to the process group
#         #         os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
#         #         self.process = None
#         #         print("SLAM process stopped")
#         #     except Exception as e:
#         #         print(f"Failed to stop SLAM process: {e}")
#         #     finally:
#         #         # Clear the folder
#         #         folder_path = "/home/parthasaradhi-n/Desktop/Project/Digital-Heritage-main/Data/Features/"
#         #         try:
#         #             for item in os.listdir(folder_path):
#         #                 item_path = os.path.join(folder_path, item)
#         #                 if os.path.isfile(item_path) or os.path.islink(item_path):
#         #                     os.unlink(item_path)  # Remove file or symbolic link
#         #                 elif os.path.isdir(item_path):
#         #                     shutil.rmtree(item_path)  # Remove directory
#         #             print(f"Folder '{folder_path}' has been cleared.")
#         #         except Exception as e:
#         #             print(f"Failed to clear folder: {e}")

#         #         # Re-enable buttons
#         #         self.start_button.set_sensitive(True)
#         #         self.stop_button.set_sensitive(False)
#         """ Stop the SLAM process and close related windows. """
#         if self.process:
#                 try:
#                     os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)  # Kill process group
#                     self.process = None
#                     print("SLAM process stopped.")
#                 except Exception as e:
#                     print(f"Failed to stop SLAM process: {e}")

#         self.close_map_viewer()  # Ensure viewer window is closed

#         self.start_button.set_sensitive(True)
#         self.stop_button.set_sensitive(False)



    

# if __name__ == "__main__":
#     app = LiveMapWindow()
#     app.connect("destroy", Gtk.main_quit)
#     app.show_all()
#     Gtk.main()
#2222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222
# import gi
# import subprocess
# import os
# import time
# from gi.repository import Gtk, GLib, Gdk
# from location_admin import LocationPage
# # from logs import LogViewerWindow
# from logs import show_logs
# from features import Features
# import signal
# import shutil
# import threading
# import sys

# gi.require_version('Gtk', '3.0')

# LOG_FILE = "live_debug_logs.txt"
# class LiveMapWindow(Gtk.Window):
#     def __init__(self):
#         Gtk.Window.__init__(self, title="Digital Heritage - Admin")
#         self.set_default_size(1000, 800)
#         self.maximize()
#         self.set_titlebar(self.create_header_bar())
#         #added these two lines for logs
#         sys.stdout = open(LOG_FILE, "w", buffering=1)  # Line-buffered
#         sys.stderr = sys.stdout 

#         self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
#         self.add(self.main_paned)

#         self.fixed_button_width = 200

#         self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         self.button_box.set_size_request(self.fixed_button_width, -1)
#         self.main_paned.pack2(self.button_box, resize=False, shrink=False)

#         self.start_button = Gtk.Button(label="Start")
#         self.start_button.connect("clicked", self.on_start_button_clicked)
#         self.button_box.pack_start(self.start_button, False, False, 0)

#         self.stop_button = Gtk.Button(label="Stop")
#         self.stop_button.connect("clicked", self.on_stop_clicked)
#         self.button_box.pack_start(self.stop_button, False, False, 0)

#         self.logs_button = Gtk.Button(label="Show logs")
#         # self.logs_button.connect("clicked", self.on_show_logs_clicked)
#         self.logs_button.connect("clicked", self.show_logs)
#         self.button_box.pack_start(self.logs_button, False, False, 0)

#         self.features_button = Gtk.Button(label="Show features")
#         self.features_button.connect("clicked", self.on_show_features_clicked)
#         self.button_box.pack_start(self.features_button, False, False, 0)

#         self.map_area = Gtk.DrawingArea()
#         self.map_area.set_size_request(800, 600)
#         self.main_paned.pack1(self.map_area, resize=True, shrink=True)

#         self.process = None
#         self.viewer_window_id = None
#         self.logs_open = False
#         self.features_open = False
#         self.is_action_in_progress = False
#         self.connect("focus-in-event", self.on_focus_in)
#         # self.connect("focus-out-event", self.on_focus_out)
#         GLib.timeout_add_seconds(1, self.on_focus_in)

        

#         GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

#     def on_start_button_clicked(self, widget):
#         self.start_button.set_sensitive(False)

#         if self.process:
#             self.process.terminate()
#             self.process = None
        
#         command = "./test_webcam_2.sh"
#         current_dir = os.path.abspath(os.path.dirname(__file__))
#         base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
#         directory = os.path.join(base_dir, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
#         frame_dir = os.path.join(base_dir, "Data/Features/")
#         os.makedirs(frame_dir, exist_ok=True)

#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"

#         try:
#             # self.process = subprocess.Popen(
#             #     command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid,stdout=subprocess.PIPE,
#             #     stderr=subprocess.PIPE,
#             #     text=True
#             # )
#             # threading.Thread(target=self.read_logs, daemon=True).start()
   

#             self.process = subprocess.Popen(
#                 command,
#                 shell=True,
#                 env=env,
#                 cwd=directory,
#                 preexec_fn=os.setsid,  # Ensures subprocess is in a new session
#                 # stdout=subprocess.PIPE,
#                 # stderr=subprocess.PIPE,
#                 text=True
#             )

#             # Start a thread to continuously read logs
#             threading.Thread(target=self.read_logs, daemon=True).start()

#             time.sleep(5)
#             for _ in range(10):
#                 time.sleep(1)
#                 if self.move_window():
#                     break
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)

    

#     def on_show_logs_clicked(self, widget):
#         print(f"Minimizing Map Viewer window ID: {self.viewer_window_id}")
#         self.logs_open = True
#         subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        
#         log_window = LogViewerWindow(self)
       
#         log_window.show_all()
#         log_window.set_keep_above(True)
        
#     def show_logs(self, widget):
#         show_logs()

#     def on_show_features_clicked(self, widget):
#         self.features_open = True
#         subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])

       
#         feat = Features(self)
#         feat.show_all()
#         feat.set_keep_above(True)
    
#     def read_logs(self):
#         """Reads subprocess output and saves it to a log file."""
#         with open(LOG_FILE, "w") as log_file:
#             while self.process.poll() is None:
#                 output = self.process.stdout.readline()
#                 error = self.process.stderr.readline()

#                 if output:
#                     log_file.write(output)
#                     log_file.flush()
#                 if error:
#                     log_file.write(error)
#                     log_file.flush()
    
        
    

#     def move_window(self):
#         try:
#             result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
#             windows = result.stdout.splitlines()
#             for window in windows:
#                 if "ORB-SLAM3: Map Viewer" in window:
#                     self.viewer_window_id = window.split()[0]
#                     subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
#                                     '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])
#                     self.resize_and_position_viewer()
#                     return True
#             return False
#         except Exception as e:
#             print(f"Error moving window: {e}")
#             return False

#     def on_focus_in(self, widget, event):
#         if self.viewer_window_id:
#             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             self.resize_and_position_viewer()

        
#         subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])
#         # return

   

#     def resize_and_position_viewer(self):
#         if self.viewer_window_id:
#             app_x, app_y = self.get_position()
#             width, height = self.get_size()
#             available_width = width - self.fixed_button_width
#             available_height = height
#             try:
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
#                                 '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'])
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             except Exception as e:
#                 print(f"Error resizing Map Viewer: {e}")

#     def check_and_resize_map_viewer(self):
#         if self.viewer_window_id:
#             self.move_window()
#             self.resize_and_position_viewer()
#         if  not self.logs_open or not self.features_open :
#             print("window map restored")
#             subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        
        
#         return True

#     def close_map_viewer(self):
#         if self.viewer_window_id:
#             try:
#                 subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
#             except Exception as e:
#                 print(f"Failed to close Map Viewer: {e}")


#     def create_header_bar(self):
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)
#         header_bar.pack_start(back_button)
#         return header_bar

#     def on_back_button_clicked(self, widget):
#         app = LocationPage()
#         app.show_all()
#         self.hide()

#     def on_stop_clicked(self, widget):
#         if self.process:
#             try:
#                 print("Stopping SLAM process...")

#                 # Send SIGINT (equivalent to Ctrl+C)
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)

#                 # Wait a bit for the process to clean up and save the map
#                 time.sleep(5)  # Adjust this delay if needed

#                 # If the process is still running, force stop it
#                 self.process.terminate()
#                 self.process.wait()
#                 self.process = None

#                 print("SLAM process stopped successfully.")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")

#         self.close_map_viewer()
#         self.start_button.set_sensitive(True)
#         self.stop_button.set_sensitive(False)


# if __name__ == "__main__":
#     app = LiveMapWindow()
#     app.connect("destroy", Gtk.main_quit)
#     app.show_all()
#     Gtk.main()

#22222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222
import gi
import subprocess
import os
import time
import signal
import shutil
import threading
import sys
from gi.repository import Gtk, GLib, Gdk
from location_debug import LocationPage
from logs import LogWindow
from features import Features

gi.require_version('Gtk', '3.0')

LOG_FILE = "live_debug_logs.txt"

class LiveMapWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Digital Heritage - Admin")
        self.set_default_size(1000, 800)
        self.maximize()
        self.set_titlebar(self.create_header_bar())

        # Redirect stdout and stderr to a log file
        sys.stdout = open(LOG_FILE, "w", buffering=1)  
        sys.stderr = sys.stdout  

        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)

        self.fixed_button_width = 200

        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)

        self.start_button = Gtk.Button(label="Start")
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        self.logs_button = Gtk.Button(label="Show logs")
        self.logs_button.connect("clicked", self.on_show_logs_clicked)
        self.button_box.pack_start(self.logs_button, False, False, 0)

        self.features_button = Gtk.Button(label="Show features")
        self.features_button.connect("clicked", self.on_show_features_clicked)
        self.button_box.pack_start(self.features_button, False, False, 0)

        self.map_area = Gtk.DrawingArea()
        self.map_area.set_size_request(800, 600)
        self.main_paned.pack1(self.map_area, resize=True, shrink=True)

        self.process = None
        self.viewer_window_id = None
        self.logs_open = False
        self.features_open = False

        self.connect("focus-in-event", self.on_focus_in)
        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)
       
        self.start_logging() 

        if self.process:
            self.process.terminate()
            self.process = None
        
        command = "./test_webcam_2.sh"
        current_dir = os.path.abspath(os.path.dirname(__file__))
        base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
        directory = os.path.join(base_dir, "ORB_SLAM3/Examples/Monocular/Run_Scripts/")
        frame_dir = os.path.join(base_dir, "Data/Features/")
        os.makedirs(frame_dir, exist_ok=True)

        env = os.environ.copy()
        env["DISPLAY"] = ":0"

        try:
            self.process = subprocess.Popen(
                command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid, text=True
            )

            # threading.Thread(target=self.read_logs, daemon=True).start()

            time.sleep(5)
            for _ in range(10):
                time.sleep(1)
                if self.move_window():
                    break
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)

    def start_logging(self):
        """Ensure logging starts immediately when SLAM starts."""
        if not os.path.exists("live_debug_logs.txt"):
            open("live_debug_logs.txt", "w").close()  # ✅ Ensure log file exists
        self.log_thread = threading.Thread(target=self.monitor_logs, daemon=True)
        self.log_thread.start()

    def monitor_logs(self):
        """Continuously monitor and write logs for debugging."""
        with open("live_debug_logs.txt", "a", encoding="utf-8") as log_file:
            while True:
                log_file.write(f"New log entry at {time.strftime('%H:%M:%S')}\n")  # ✅ Simulate log writing
                log_file.flush()  # ✅ Ensure logs are written instantly
                time.sleep(1)  # Simulate log update

    def on_show_logs_clicked(self, widget):
        print(f"Minimizing Map Viewer window ID: {self.viewer_window_id}")
        self.logs_open = True
        subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        # threading.Thread(target=self._delayed_show_logs, daemon=True).start()
        log=LogWindow()
        GLib.idle_add(self.focus_on_window, log)
        # Ensure we detect when features window is closed
        log.connect("destroy", lambda w: self.set_logs_closed())

        log.show_all()
        
        log.set_keep_above(True)

    def on_show_features_clicked(self, widget):
        self.features_open = True
        subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        feat = Features(self)
        GLib.idle_add(self.focus_on_window, feat)
        # Ensure we detect when features window is closed
        feat.connect("destroy", lambda w: self.set_features_closed())

        feat.show_all()
        
        feat.set_keep_above(True)

    
    # def _delayed_show_logs(self):
    #     show_logs(self)
    #      # Small delay to ensure logs window fully opens
    #     self.logs_open = True

    def set_logs_closed(self):
        """Called when Features window is closed."""
        self.logs_open = False
        GLib.timeout_add(500, self.check_and_resize_map_viewer)

    def set_features_closed(self):
        """Called when Features window is closed."""
        self.features_open = False
        GLib.timeout_add(500, self.check_and_resize_map_viewer)

    def read_logs(self):
        """Reads subprocess output and saves it to a log file."""
        with open(LOG_FILE, "w") as log_file:
            while self.process.poll() is None:
                output = self.process.stdout.readline()
                error = self.process.stderr.readline()

                if output:
                    log_file.write(output)
                    log_file.flush()
                if error:
                    log_file.write(error)
                    log_file.flush()

    def move_window(self):
        try:
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:
                    self.viewer_window_id = window.split()[0]
                    subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
                                    '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])
                    self.resize_and_position_viewer()
                    return True
            return False
        except Exception as e:
            print(f"Error moving window: {e}")
            return False

    def on_focus_in(self, widget, event):
        if self.viewer_window_id:
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
            self.resize_and_position_viewer()
            subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])
    def focus_on_window(self, window):
        """Force the Features window to get focus before it opens."""
        try:
            xid = window.get_window().get_xid()  # Get Features window XID
            subprocess.run(['xdotool', 'windowactivate', str(xid)])  # Activate it immediately
        except Exception as e:
            print(f"Error focusing on Features window: {e}")

    def resize_and_position_viewer(self):
        if self.viewer_window_id:
            app_x, app_y = self.get_position()
            width, height = self.get_size()
            available_width = width - self.fixed_button_width
            available_height = height
            try:
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
                                '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'])
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
            except Exception as e:
                print(f"Error resizing Map Viewer: {e}")

    def check_and_resize_map_viewer(self):
        if self.viewer_window_id:
            self.move_window()
            self.resize_and_position_viewer()

        # # Restore Map Viewer only if logs & features are both closed
        # if not self.logs_open and not self.features_open:
        #     print("Restoring Map Viewer window")
        #     GLib.timeout_add(2000, self.restore_map_viewer)  # Small delay before restoring
         # Ensure the Map Viewer does NOT automatically gain focus
        if self.logs_open or self.features_open:
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,below'])
            return True
        # Restore Map Viewer only if logs & features are both closed
        elif not self.logs_open and not self.features_open:
            print("Restoring Map Viewer window")
            subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])
            subprocess.run(['xdotool', 'windowmap', self.viewer_window_id])  
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'remove,below'])
        return True
    
    def restore_map_viewer(self):
        """Restores Map Viewer after ensuring logs and features are closed."""
        if not self.logs_open and not self.features_open:
            print("Restoring Map Viewer window")
            subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])
            subprocess.run(['xdotool', 'windowmap', self.viewer_window_id])

    def close_map_viewer(self):
        if self.viewer_window_id:
            try:
                subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
            except Exception as e:
                print(f"Failed to close Map Viewer: {e}")

    def create_header_bar(self):
        header_bar = Gtk.HeaderBar(title="Add New Map")
        header_bar.set_show_close_button(True)
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)
        header_bar.pack_start(back_button)
        return header_bar

    def on_back_button_clicked(self, widget):
        app = LocationPage()
        app.show_all()
        self.hide()

    def on_stop_clicked(self, widget):
        if self.process:
            os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
            time.sleep(5)
            self.process.terminate()
            self.process.wait()
            self.process = None

        self.close_map_viewer()
        self.start_button.set_sensitive(True)
        self.stop_button.set_sensitive(False)

if __name__ == "__main__":
    app = LiveMapWindow()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()
