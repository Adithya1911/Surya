
import gi
import subprocess
import threading
from gi.repository import Gtk, GLib

gi.require_version('Gtk', '3.0')

LOG_FILE = "app_logs.txt"  # Read from the same log file as your main app

class LogViewerWindow:
    def __init__(self, live_debug_ref=None):
        # def __init__(self, live_debug_ref=None):
        super().__init__(title="Logs")
        self.maximize()
        self.set_border_width(10)
        self.live_debug = live_debug_ref  # This can be None if not provided
        self.set_titlebar(self.create_header_bar())

        # Create a TextView for logs
        self.log_view = Gtk.TextView()
        self.log_view.set_editable(False)
        self.log_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.log_buffer = self.log_view.get_buffer()

        # Scrollable window for logs
        self.scrolled_window = Gtk.ScrolledWindow()
        self.scrolled_window.set_hexpand(True)
        self.scrolled_window.set_vexpand(True)
        self.scrolled_window.add(self.log_view)

        # Add to window
        self.add(self.scrolled_window)

        # Start capturing logs
        self.capture_logs()

    def capture_logs(self):
        """Captures both system and terminal logs and updates the log view."""
        def run_log_capture():
            # Consider handling tail and journalctl separately if needed.
            process = subprocess.Popen(
                ['bash', '-c', f'tail -f {LOG_FILE} & journalctl -f'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            while True:
                output = process.stdout.readline()
                if output:
                    GLib.idle_add(self.update_log_view, output)
                if process.poll() is not None:
                    break
        
        log_thread = threading.Thread(target=run_log_capture, daemon=True)
        log_thread.start()

    def update_log_view(self, log_text):
        """Appends new logs to the TextView."""
        end_iter = self.log_buffer.get_end_iter()
        self.log_buffer.insert(end_iter, log_text)
        # Auto-scroll to the bottom
        adj = self.scrolled_window.get_vadjustment()
        adj.set_value(adj.get_upper())

    def create_header_bar(self):
        header_bar = Gtk.HeaderBar(title="Logs")
        header_bar.set_show_close_button(True)
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)
        header_bar.pack_start(back_button)
        return header_bar

    def on_back_button_clicked(self, widget):
        if self.live_debug:
            self.live_debug.show_all()
        self.hide()
