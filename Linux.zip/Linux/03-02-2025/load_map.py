import gi
import os
import open3d as o3d

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

class LoadMap(Gtk.Window):
    def __init__(self,parent=None):
        super().__init__(title="Load Map")
        self.maximize()
        self.set_border_width(20)
        self.set_default_size(800, 300)
        self.set_keep_above(True)
        self.set_titlebar(self.create_header_bar())
        self.parent=parent
        self.set_position(Gtk.WindowPosition.CENTER)
        
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        self.add(frame)
        self.main_layout = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        frame.add(self.main_layout)
        
        self.select_script_button = Gtk.Button(label="Select Map")
        self.select_script_button.set_halign(Gtk.Align.CENTER)
        self.select_script_button.connect("clicked", self.on_select_script)
        self.main_layout.pack_start(self.select_script_button, False, False, 0)

        self.script_label = Gtk.Label(label="No Map selected")
        self.script_label.set_halign(Gtk.Align.CENTER)
        self.main_layout.pack_start(self.script_label, False, False, 0)
        
        
        self.load_button = Gtk.Button(label="Load Map")
        self.load_button.set_halign(Gtk.Align.CENTER)
        self.load_button.connect("clicked", self.on_load)
        self.main_layout.pack_start(self.load_button, False, False, 0)
        
        self.selected_folder = None
        self.selected_script = None
    
    def on_select_script(self, widget):
        dialog = Gtk.FileChooserDialog(
            title="Please choose a file",
            parent=self,
            action=Gtk.FileChooserAction.OPEN,
            buttons=(
                Gtk.STOCK_CANCEL,
                Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OPEN,
                Gtk.ResponseType.OK,
            ),
        )
        dialog.set_select_multiple(False)
        dialog.set_current_folder(self.selected_folder or os.getcwd())
        ply_filter = Gtk.FileFilter()
        ply_filter.set_name("PLY files")
        ply_filter.add_pattern("*.ply")
        dialog.add_filter(ply_filter)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.selected_script = dialog.get_filename()
            self.script_label.set_text(self.selected_script)
            self.selected_folder = dialog.get_current_folder()
        dialog.destroy()
        
        
    
    def create_header_bar(self):
        """Creates a custom header bar with a Back button."""
        header_bar = Gtk.HeaderBar(title="Digital Heritage")
        header_bar.set_show_close_button(True)

        # Create Back Button
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)

        # Add the back button to the left side of the header
        header_bar.pack_start(back_button)
        
        return header_bar
    
    def on_load(self, widget):
        
        try:            
            if self.selected_script is None:
                dialog = Gtk.MessageDialog(
                    transient_for=self,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text="No Map selected",
                )
                dialog.run()
                dialog.destroy()
                return
            print("Load Map clicked.")
        # Add your load action here, like loading the selected map.
            point_cloud = o3d.io.read_point_cloud(self.selected_script)
            if not point_cloud.has_points():
                print("Error: Ply file has not valid points")   
                return
            o3d.visualization.draw_geometries([point_cloud])
            print("Map loaded successfully")
        except Exception as e:
            print(f"Error loading map: {e}")
        
        
    
    def on_back_button_clicked(self, widget):
        if self.parent:
            self.parent.show_all()
            self.parent.set_keep_above(True)
            self.hide()
        self.connect("destroy",Gtk.main_quit)
    

if __name__ == "__main__":
    win = LoadMap()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()