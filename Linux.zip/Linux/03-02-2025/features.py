import gi
import os
import shutil
import time
from gi.repository import Gtk, GdkPixbuf, GLib
# from live_debug import LiveMapWindow

gi.require_version("Gtk", "3.0")

# Configuration

class Features(Gtk.Window):
    def __init__(self,live_debug_ref):
        super().__init__(title="Digital Heritage - Admin")
        self.set_default_size(800, 600)
        self.maximize()
        self.set_titlebar(self.create_header_bar())
        self.live_debug=live_debug_ref

        self.set_position(Gtk.WindowPosition.CENTER_ALWAYS)
        self.set_border_width(10)

        self.last_frame = None
        self.timeout = 5000  # Timeout in milliseconds
        self.last_update = time.time()

        self.viewer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.viewer_box.set_halign(Gtk.Align.CENTER)
        self.viewer_box.set_valign(Gtk.Align.CENTER)
        self.add(self.viewer_box)

        self.image = Gtk.Image()
        self.label = Gtk.Label(label="Waiting for frames...")
        self.viewer_box.pack_start(self.image, True, True, 0)
        self.viewer_box.pack_start(self.label, False, False, 0)
        self.current_dir = os.path.abspath(os.path.dirname(__file__))
        self.base_dir = os.path.abspath(os.path.join(self.current_dir, "../../"))
        self.Frame_Dir = os.path.join(self.base_dir, "Linux/frames")
        os.makedirs(self.Frame_Dir, exist_ok=True)

        GLib.timeout_add(35, self.update_frame)

    def create_header_bar(self):
        header_bar = Gtk.HeaderBar(title="Features")
        header_bar.set_show_close_button(True)

        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)
        header_bar.pack_start(back_button)

        return header_bar

    def on_back_button_clicked(self, widget):  
        self.live_debug.set_keep_above(True)     
        self.live_debug.show_all()
        self.hide()
        print("Back button clicked")

    def update_frame(self):
        frame_path = os.path.join(self.Frame_Dir, "frame.jpg")

        # Check if frame.jpg exists
        if not os.path.exists(frame_path):
            self.show_placeholder()
            return True

        # Get the modification time of the file
        try:
            mod_time = os.path.getmtime(frame_path)
            if mod_time != self.last_update:
                # File has been updated, reload and display it
                pixbuf = GdkPixbuf.Pixbuf.new_from_file(frame_path)
                self.image.set_from_pixbuf(pixbuf)
                self.label.set_text("")
                self.last_update = mod_time  # Update the last seen modification time
            else:
                # File hasn't changed, show placeholder if needed
                if time.time() - self.last_update > self.timeout / 1000:
                    self.show_placeholder()
        except Exception as e:
            print(f"Error reading frame.jpg: {e}")

        return True


    def show_placeholder(self):
        self.label.set_text("Waiting for frames...")
        if self.last_frame is None:
            self.image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)

if __name__ == "__main__":
    app = Features()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()