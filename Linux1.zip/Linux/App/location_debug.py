import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from app import LinuxApp
class LocationPage(Gtk.Window):
    def __init__(self):
        super().__init__(title="Location Management")
        
        # Maximize window by default
        self.maximize()
        self.set_titlebar(self.create_header_bar())

        # Main layout: Vertical box
        self.main_layout = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(self.main_layout)

        # Centering container
        self.center_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=20,
            margin=40
        )
        self.center_box.set_valign(Gtk.Align.CENTER)  # Center vertically
        self.center_box.set_halign(Gtk.Align.CENTER)  # Center horizontally
        self.main_layout.pack_start(self.center_box, True, True, 0)

        # # Title label
        # title_label = Gtk.Label(label="Location Management")
        # title_label.set_halign(Gtk.Align.CENTER)
        # title_label.get_style_context().add_class("title")
        # title_label.set_margin_bottom(20)
        # self.center_box.pack_start(title_label, False, False, 0)

        # Add 'Add New Location' button
        add_location_button = Gtk.Button(label="Add Map")
        add_location_button.connect("clicked", self.on_add_location)
        self.center_box.pack_start(add_location_button, False, False, 0)

        # Add 'Previous Records' button
        records_button = Gtk.Button(label="Load Map")
        records_button.connect("clicked", self.on_previous_records)
        self.center_box.pack_start(records_button, False, False, 0)
    
    def create_header_bar(self):
        """Creates a custom header bar with a Back button."""
        header_bar = Gtk.HeaderBar(title="Digital Heritage")
        header_bar.set_show_close_button(True)

        # Create Back Button
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)

        # Add the back button to the left side of the header
        header_bar.pack_start(back_button)
        
        return header_bar

    def on_back_button_clicked(self, widget):
        """Handle the back button click event."""
        app=LinuxApp()
        app.show_all()
        self.hide()
        print("Back button clicked")
        # Add your back action here, like navigating to a previous screen.
    

    def on_add_location(self, button):
        """Action for adding a new location."""
      
        print("Add New Location clicked.")
        from live_debug import LiveMapWindow
        app = LiveMapWindow()
        app.show_all()
        self.hide()

    def on_previous_records(self, button):
        """Action for viewing previous records."""
      
        print("Previous Records clicked.")
        from recorded_admin import ScriptRunnerWindow
        records_window = ScriptRunnerWindow()
        records_window.show_all()
        self.hide()


# Main program to run the Location Page
if __name__ == "__main__":
    win = LocationPage()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()