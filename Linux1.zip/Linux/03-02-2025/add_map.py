import gi
import subprocess
import os
import time
from gi.repository import Gtk,GLib
gi.require_version("Gtk", "3.0")
import signal
# import shutil



    # def __init__(self,parent=None):
    #     super().__init__(self,title="User New Map")
    #     self.maximize()
    #     self.set_titlebar(self.create_header_bar())
    #     self.parent = parent
    #     self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
    #     self.add(self.main_paned)
    #     self.fixed_button_width = 200
    #     self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    #     self.button_box.set_size_request(self.fixed_button_width, -1)
    #     self.main_paned.pack2(self.button_box, resize=False, shrink=False)

    #     # Start
    #     self.start_button = Gtk.Button(label="Start")
    #     self.start_button.connect("clicked", self.on_start_button_clicked)
    #     self.button_box.pack_start(self.start_button, False, False, 0)
    #     #stop
    #     self.stop_button = Gtk.Button(label="Stop")
    #     self.stop_button.connect("clicked", self.on_stop_clicked)
    #     self.button_box.pack_start(self.stop_button, False, False, 0)
    #     #Map Area
    #     self.map_area = Gtk.DrawingArea()
    #     self.map_area.set_size_request(800, 600)
    #     self.main_paned.pack1(self.map_area, resize=True, shrink=True)
    #     self.process = None
    #     self.viewer_window_id = None
    #     self.is_action_in_progress = False
    #     # self.connect("focus-in-event", self.on_focus_in)
    #     # # self.connect("focus-out-event", self.on_focus_out)
    #     # GLib.timeout_add_seconds(1, self.on_focus_in)
    #     GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)
    
    # def on_back_button_clicked(self,**args):
    #     self.parent.show_all()
    #     # self.destroy()
    #     self.hide()

    # def on_start_button_clicked(self, widget):
    #     self.start_button.set_sensitive(False)

    #     if self.process:
    #         self.process.terminate()
    #         self.process = None
        
    #     command = "./test_webcam_2.sh"
    #     current_dir = os.path.abspath(os.path.dirname(__file__))
    #     base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
    #     directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
    #     frame_dir = os.path.join(base_dir, "../frames")
    #     os.makedirs(frame_dir, exist_ok=True)

    #     env = os.environ.copy()
    #     env["DISPLAY"] = ":0"

    #     try:
    #         env = os.environ.copy()
    #         env["DISPLAY"] = ":0"

    #         self.process = subprocess.Popen(
    #             command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid
    #         )
    #         time.sleep(5)
    #         for _ in range(10):
    #             time.sleep(1)
    #             if self.move_window():
    #                 break
    #     except Exception as e:
    #         print(f"Failed to start SLAM process: {e}")
    #         self.start_button.set_sensitive(True)
            
    # def move_window(self):
    #     try:
    #         result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
    #         windows = result.stdout.splitlines()
    #         for window in windows:
    #             if "ORB-SLAM3: Map Viewer" in window:
    #                 self.viewer_window_id = window.split()[0]
    #                 subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
    #                                 '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])
    #                 self.resize_and_position_viewer()
    #                 return True
    #         return False
    #     except Exception as e:
    #         print(f"Error moving window: {e}")
    #         return False         
    
    # # def on_focus_in(self, widget, event):
    # #     if self.viewer_window_id:
    # #         subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
    # #         self.resize_and_position_viewer()

        
    # #     subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])   
    
    # def resize_and_position_viewer(self):
    #     if self.viewer_window_id:
    #         app_x, app_y = self.get_position()
    #         width, height = self.get_size()
    #         available_width = width - self.fixed_button_width
    #         available_height = height
    #         try:
    #             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
    #                             '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'])
    #             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
    #         except Exception as e:
    #             print(f"Error resizing Map Viewer: {e}")
 
    # def check_and_resize_map_viewer(self):
    #     if self.viewer_window_id:
    #         self.move_window()
    #         self.resize_and_position_viewer()
    #     return True
 
    # def close_map_viewer(self):
    #     if self.viewer_window_id:
    #         try:
    #             subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
    #         except Exception as e:
    #             print(f"Failed to close Map Viewer: {e}")   
    
    # def create_header_bar(self):
    #     header_bar = Gtk.HeaderBar(title="Add New Map")
    #     header_bar.set_show_close_button(True)
    #     back_button = Gtk.Button(label="Back")
    #     back_button.connect("clicked", self.on_back_button_clicked)
    #     header_bar.pack_start(back_button)
    #     return header_bar
    
    # def on_stop_clicked(self, widget):
    #     if self.process:
    #         try:
    #             print("Stopping SLAM process...")

    #             # Send SIGINT (equivalent to Ctrl+C)
    #             os.killpg(os.getpgid(self.process.pid), signal.SIGINT)

    #             # Wait a bit for the process to clean up and save the map
    #             time.sleep(5)  # Adjust this delay if needed

    #             # If the process is still running, force stop it
    #             self.process.terminate()
    #             self.process.wait()
    #             self.process = None

    #             print("SLAM process stopped successfully.")
    #         except Exception as e:
    #             print(f"Failed to stop SLAM process: {e}")

    #     # self.close_map_viewer()
    #     self.start_button.set_sensitive(True)
    #     self.stop_button.set_sensitive(False)

        



# class User_New_Map(Gtk.Window):
#     def __init__(self, parent=None, username="User"):
#         super().__init__(title=f"{username} - Debug Map")
#         screen=self.get_screen()
#         width,height=screen.get_width(),screen.get_height()
#         self.set_default_size(width,height)

#         # self.set_default_size(800, 600)
#         self.fullscreen()
#         self.set_border_width(10)
#         self.set_keep_above(True)
        
#         self.set_titlebar(self.create_header_bar(username))
#         self.parent = parent

#         # Create a horizontal paned container
#         self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
#         self.add(self.main_paned)

#         # Fixed width for the button area
#         self.fixed_button_width = 200

#         # Create a vertical box for the buttons
#         self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         self.button_box.set_size_request(self.fixed_button_width, -1)
#         self.main_paned.pack2(self.button_box, resize=False, shrink=False)

#         # Create Start and Stop buttons
#         self.back_button = Gtk.Button(label="Back")
#         self.back_button.connect("clicked", self.on_back_button_clicked)
#         self.button_box.pack_end(self.back_button,False,False,0)
        
#         self.start_button = Gtk.Button(label="Start")
#         self.start_button.connect("clicked", self.on_start_button_clicked)
#         self.button_box.pack_start(self.start_button, False, False, 0)

#         self.stop_button = Gtk.Button(label="Stop")
#         self.stop_button.connect("clicked", self.on_stop_clicked)
#         self.button_box.pack_start(self.stop_button, False, False, 0)


#         # Create a drawing area for the map viewer
#         self.map_area = Gtk.DrawingArea()
#         self.map_area.set_size_request(800, 600)
#         self.main_paned.pack1(self.map_area, resize=True, shrink=True)

#         # Initialize process and viewer window variables
#         self.process = None
#         self.viewer_window_id = None
#         self.is_action_in_progress = False

#         # Connect focus event to ensure proper window stacking and positioning
#         self.connect("focus-in-event", self.on_focus_in)
#         GLib.timeout_add_seconds(1, self.on_focus_in, None)
#         GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

#     def create_header_bar(self, username):
#         header_bar = Gtk.HeaderBar(title=f"{username} - Debug Map")
#         header_bar.set_show_close_button(True)
#         header_bar

#     def on_back_button_clicked(self, widget):
#         if self.parent:
#             self.parent.show_all()
#         self.hide()

#     def on_start_button_clicked(self, widget):
#         self.start_button.set_sensitive(False)
#         self.stop_button.set_sensitive(True)

#         # If an existing process is running, terminate it.
#         if self.process:
#             self.process.terminate()
#             self.process = None

#         # Set up the command and environment
#         command = "./test_webcam_2.sh"
#         current_dir = os.path.abspath(os.path.dirname(__file__))
#         base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
#         directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
#         frame_dir = os.path.join(base_dir, "../frames")
#         os.makedirs(frame_dir, exist_ok=True)

#         env = os.environ.copy()
#         env["DISPLAY"] = ":1"

#         try:
#             self.process = subprocess.Popen(
#                 command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid
#             )
#             # Allow some time for the process to initialize
#             time.sleep(5)
#             # Attempt to find and move the map viewer window
#             for _ in range(10):
#                 time.sleep(1)
#                 if self.move_window():
#                     break
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)
#             self.stop_button.set_sensitive(False)

#     def move_window(self):
#         """Finds the map viewer window by its title and repositions it."""
#         try:
#             result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
#             windows = result.stdout.splitlines()
#             for window in windows:
#                 if "ORB-SLAM3: Map Viewer" in window:
#                     self.viewer_window_id = window.split()[0]
#                     # Remove window borders and decorations
#                     subprocess.run([
#                         'xprop', '-id', self.viewer_window_id, 
#                         '-f', '_MOTIF_WM_HINTS', '32c',
#                         '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'
#                     ])
#                     self.resize_and_position_viewer()
#                     return True
#             return False
#         except Exception as e:
#             print(f"Error moving window: {e}")
#             return False

#     def on_focus_in(self, widget, event):
#         """When this window receives focus, bring the map viewer above and reposition it."""
#         if self.viewer_window_id:
#             subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             self.resize_and_position_viewer()
#             subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])

#     def resize_and_position_viewer(self):
#         """Resize and position the map viewer to fill the available area next to the button box."""
#         if self.viewer_window_id:
#             app_x, app_y = self.get_position()
#             width, height = self.get_size()
#             available_width = width - self.fixed_button_width
#             available_height = height
#             try:
#                 subprocess.run([
#                     'wmctrl', '-i', '-r', self.viewer_window_id,
#                     '-e', f'0,{app_x},{app_y},{available_width},{available_height}'
#                 ])
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             except Exception as e:
#                 print(f"Error resizing Map Viewer: {e}")

#     def check_and_resize_map_viewer(self):
#         """Periodically check and adjust the map viewer window."""
#         if self.viewer_window_id:
#             self.move_window()
#             self.resize_and_position_viewer()
#         return True

#     def close_map_viewer(self):
#         if self.viewer_window_id:
#             try:
#                 subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
#             except Exception as e:
#                 print(f"Failed to close Map Viewer: {e}")

#     def on_stop_clicked(self, widget):
#         if self.process:
#             try:
#                 print("Stopping SLAM process...")
#                 # Send SIGINT to allow graceful shutdown (Ctrl+C)
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
#                 # Allow some time for cleanup
#                 time.sleep(5)
#                 # Force termination if still running
#                 self.process.terminate()
#                 self.process.wait()
#                 self.process = None
#                 print("SLAM process stopped successfully.")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")

#         self.close_map_viewer()
#         self.start_button.set_sensitive(True)
#         self.stop_button.set_sensitive(False)




class User_New_Map(Gtk.Window):
    def __init__(self, parent=None, username="User"):
        super().__init__(title=f"{username} - Debug Map")
        
        screen = self.get_screen()
        width, height = screen.get_width(), screen.get_height()
        self.set_default_size(width, height)

        # Make the window fullscreen and add border width
        self.fullscreen()
        # self.set_border_width(10)
        self.set_keep_above(True)
        
        # Set the header bar
        self.set_titlebar(self.create_header_bar(username))
        self.parent = parent

        # Create a horizontal paned container
        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)

        # Fixed width for the button area
        self.fixed_button_width = 200

        # Create a vertical box for the buttons
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)  # Prevent resizing width

        # Create Start and Stop buttons
        self.back_button = Gtk.Button(label="Back")
        self.back_button.connect("clicked", self.on_back_button_clicked)
        self.button_box.pack_end(self.back_button, False, False, 0)
        
        self.start_button = Gtk.Button(label="Start")
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        # Create a drawing area for the map viewer
        self.map_area = Gtk.DrawingArea()

        # Now pack the map area in the first pane (left side)
        self.main_paned.pack1(self.map_area, resize=True, shrink=True)  # Ensure map area resizes with the window

        # Pack the button box in the second pane (right side)
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)  # Fixed size for button box

        # Initialize process and viewer window variables
        self.process = None
        self.viewer_window_id = None
        self.is_action_in_progress = False

        # Connect focus event to ensure proper window stacking and positioning
        self.connect("focus-in-event", self.on_focus_in)
        GLib.timeout_add_seconds(1, self.on_focus_in, None)
        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

    def create_header_bar(self, username):
        header_bar = Gtk.HeaderBar(title=f"{username} - Debug Map")
        header_bar.set_show_close_button(True)
        return header_bar

    def on_back_button_clicked(self, widget):
        if self.parent:
            self.parent.show_all()
        self.hide()

    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)
        self.stop_button.set_sensitive(True)

        # If an existing process is running, terminate it.
        if self.process:
            self.process.terminate()
            self.process = None

        # Set up the command and environment
        command = "./test_webcam_2.sh"
        current_dir = os.path.abspath(os.path.dirname(__file__))
        base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
        directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
        frame_dir = os.path.join(base_dir, "../frames")
        os.makedirs(frame_dir, exist_ok=True)

        env = os.environ.copy()
        env["DISPLAY"] = ":1"

        try:
            self.process = subprocess.Popen(
                command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid
            )
            # Allow some time for the process to initialize
            time.sleep(5)
            # Attempt to find and move the map viewer window
            for _ in range(10):
                time.sleep(1)
                if self.move_window():
                    break
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)
            self.stop_button.set_sensitive(False)

    def move_window(self):
        """Finds the map viewer window by its title and repositions it."""
        try:
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:
                    self.viewer_window_id = window.split()[0]
                    # Remove window borders and decorations
                    subprocess.run([
                        'xprop', '-id', self.viewer_window_id, 
                        '-f', '_MOTIF_WM_HINTS', '32c',
                        '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'
                    ])
                    self.resize_and_position_viewer()
                    return True
            return False
        except Exception as e:
            print(f"Error moving window: {e}")
            return False

    def on_focus_in(self, widget, event):
        """When this window receives focus, bring the map viewer above and reposition it."""
        if self.viewer_window_id:
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
            self.resize_and_position_viewer()
            subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])

    def resize_and_position_viewer(self):
        """Resize and position the map viewer to fill the available area next to the button box."""
        if self.viewer_window_id:
            app_x, app_y = self.get_position()
            width, height = self.get_size()
            app_x-=26
            app_y-=23
            available_width = width - self.fixed_button_width
            available_height = height
            try:
                subprocess.run([
                    'wmctrl', '-i', '-r', self.viewer_window_id,
                    '-e', f'0,{app_x},{app_y},{available_width},{available_height}'
                ])
                print(app_x,app_y)
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
            except Exception as e:
                print(f"Error resizing Map Viewer: {e}")

    def check_and_resize_map_viewer(self):
        """Periodically check and adjust the map viewer window."""
        if self.viewer_window_id:
            self.move_window()
            self.resize_and_position_viewer()
        return True

    def close_map_viewer(self):
        if self.viewer_window_id:
            try:
                subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
            except Exception as e:
                print(f"Failed to close Map Viewer: {e}")

    def on_stop_clicked(self, widget):
        if self.process:
            try:
                print("Stopping SLAM process...")
                # Send SIGINT to allow graceful shutdown (Ctrl+C)
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                # Allow some time for cleanup
                time.sleep(5)
                # Force termination if still running
                self.process.terminate()
                self.process.wait()
                self.process = None
                print("SLAM process stopped successfully.")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")

        self.close_map_viewer()
        self.start_button.set_sensitive(True)
        self.stop_button.set_sensitive(False)


# class Debug_New_Map(Gtk.Window):
#     def __init__(self,parent=None):
#         super().__init__(title="Debug New Map")
#         self.set_default_size(1000, 800)
#         self.maximize()
#         self.set_titlebar(self.create_header_bar())
#         self.parent = parent
#         self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
#         self.add(self.main_paned)

#         self.fixed_button_width = 200

#         self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
#         self.button_box.set_size_request(self.fixed_button_width, -1)
#         self.main_paned.pack2(self.button_box, resize=False, shrink=False)

#         self.start_button = Gtk.Button(label="Start")
#         self.start_button.connect("clicked", self.on_start_button_clicked)
#         self.button_box.pack_start(self.start_button, False, False, 0)

#         self.stop_button = Gtk.Button(label="Stop")
#         self.stop_button.connect("clicked", self.on_stop_clicked)
#         self.button_box.pack_start(self.stop_button, False, False, 0)

#         self.logs_button = Gtk.Button(label="Show logs")
#         self.logs_button.connect("clicked", self.on_show_logs_clicked)
#         self.button_box.pack_start(self.logs_button, False, False, 0)

#         self.features_button = Gtk.Button(label="Show features")
#         self.features_button.connect("clicked", self.on_show_features_clicked)
#         self.button_box.pack_start(self.features_button, False, False, 0)

#         self.map_area = Gtk.DrawingArea()
#         self.map_area.set_size_request(800, 600)
#         self.main_paned.pack1(self.map_area, resize=True, shrink=True)

#         self.process = None
#         self.viewer_window_id = None
#         self.logs_open = False
#         self.features_open = False
#         self.is_action_in_progress = False
#         self.connect("focus-in-event", self.on_focus_in)
#         # self.connect("focus-out-event", self.on_focus_out)
#         GLib.timeout_add_seconds(1, self.on_focus_in)

        

#         GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)

#     def on_start_button_clicked(self, widget):
#         self.start_button.set_sensitive(False)
#         self.stop_button.set_sensitive(True)

#         if self.process:
#             self.process.terminate()
#             self.process = None
        
#         command = "./test_webcam_2.sh"
#         current_dir = os.path.abspath(os.path.dirname(__file__))
#         base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
#         directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
#         frame_dir = os.path.join(base_dir, "../frames")
#         os.makedirs(frame_dir, exist_ok=True)

#         env = os.environ.copy()
#         env["DISPLAY"] = ":0"

#         try:
#             self.process = subprocess.Popen(
#                 command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid
#             )
#             time.sleep(5)
#             for _ in range(10):
#                 time.sleep(1)
#                 if self.move_window():
#                     break
#         except Exception as e:
#             print(f"Failed to start SLAM process: {e}")
#             self.start_button.set_sensitive(True)
#             self.stop_button.set_sensitive(False)

    

    # def on_show_logs_clicked(self, widget):
    #     from logs import LogViewerWindow
    #     print(f"Minimizing Map Viewer window ID: {self.viewer_window_id}")
    #     self.logs_open = True
    #     subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        
    #     log_window = LogViewerWindow(self)
       
    #     log_window.show_all()
    #     log_window.set_keep_above(True)
        
        

    # def on_show_features_clicked(self, widget):
    #     from features import Features
    #     self.set_keep_above(False)
    #     self.features_open = True
    #     subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])

       
    #     feat = Features(self)
    #     feat.show_all()
    #     feat.set_keep_above(True)
    
        
    

#     def move_window(self):
#         try:
#             result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
#             windows = result.stdout.splitlines()
#             for window in windows:
#                 if "ORB-SLAM3: Map Viewer" in window:
#                     self.viewer_window_id = window.split()[0]
#                     subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
#                                     '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])
#                     self.resize_and_position_viewer()
#                     return True
#             return False
#         except Exception as e:
#             print(f"Error moving window: {e}")
#             return False

    # def on_focus_in(self, widget, event):
    #     if self.viewer_window_id:
    #         subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
    #         self.resize_and_position_viewer()

        
    #     subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])
    #     # return

   

#     def resize_and_position_viewer(self):
#         if self.viewer_window_id:
#             app_x, app_y = self.get_position()
#             width, height = self.get_size()
#             available_width = width - self.fixed_button_width
#             available_height = height
#             try:
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
#                                 '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'])
#                 subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
#             except Exception as e:
#                 print(f"Error resizing Map Viewer: {e}")

#     def check_and_resize_map_viewer(self):
#         if self.viewer_window_id:
#             self.move_window()
#             self.resize_and_position_viewer()
#         if  not self.logs_open or not self.features_open :
#             print("window map restored")
#             subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        
        
#         return True

#     def close_map_viewer(self):
#         if self.viewer_window_id:
#             try:
#                 subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
#             except Exception as e:
#                 print(f"Failed to close Map Viewer: {e}")


#     def create_header_bar(self):
#         header_bar = Gtk.HeaderBar(title="Add New Map")
#         header_bar.set_show_close_button(True)
#         back_button = Gtk.Button(label="Back")
#         back_button.connect("clicked", self.on_back_button_clicked)
#         header_bar.pack_start(back_button)
#         return header_bar

#     def on_back_button_clicked(self, widget): 
#         if self.parent:      
#             self.parent.show_all()
#         self.hide()

#     def on_stop_clicked(self, widget):
#         if self.process:
#             try:
#                 print("Stopping SLAM process...")

#                 # Send SIGINT (equivalent to Ctrl+C)
#                 os.killpg(os.getpgid(self.process.pid), signal.SIGINT)

#                 # Wait a bit for the process to clean up and save the map
#                 time.sleep(5)  # Adjust this delay if needed

#                 # If the process is still running, force stop it
#                 self.process.terminate()
#                 self.process.wait()
#                 self.process = None

#                 print("SLAM process stopped successfully.")
#             except Exception as e:
#                 print(f"Failed to stop SLAM process: {e}")

#         self.close_map_viewer()
#         self.start_button.set_sensitive(True)
#         self.stop_button.set_sensitive(False)
    
import os
import time
import subprocess
import signal
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib


class Debug_New_Map(Gtk.Window):
    def __init__(self, parent=None):
        super().__init__(title="Debug New Map")
        self.set_default_size(1024, 600)
        screen=self.get_screen()
        width,height=screen.get_width(),screen.get_height()
        self.set_default_size(width,height)


        self.fullscreen()
        self.set_titlebar(self.create_header_bar())
        self.parent = parent
        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)

        self.fixed_button_width = 200
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)

        self.start_button = Gtk.Button(label="Start")
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        self.logs_button = Gtk.Button(label="Show logs")
        self.logs_button.connect("clicked", self.on_show_logs_clicked)
        self.button_box.pack_start(self.logs_button, False, False, 0)

        self.features_button = Gtk.Button(label="Show features")
        self.features_button.connect("clicked", self.on_show_features_clicked)
        self.button_box.pack_start(self.features_button, False, False, 0)

        self.map_area = Gtk.DrawingArea()
        self.map_area.set_size_request(1000,600)
        self.main_paned.pack1(self.map_area, resize=True, shrink=True)

        self.process = None
        self.viewer_window_id = None
        self.logs_open = False
        self.features_open = False
        self.is_action_in_progress = False
        self.connect("focus-in-event", self.on_focus_in)

        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)


    def on_show_logs_clicked(self, widget):
        from logs import LogViewerWindow
        print(f"Minimizing Map Viewer window ID: {self.viewer_window_id}")
        self.logs_open = True
        subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])
        
        log_window = LogViewerWindow(self)
       
        log_window.show_all()
        log_window.set_keep_above(True)
        
        
    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)
        self.stop_button.set_sensitive(True)

        if self.process:
            self.process.terminate()
            self.process = None

        command = "./test_webcam_2.sh"
        current_dir = os.path.abspath(os.path.dirname(__file__))
        base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
        directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
        frame_dir = os.path.join(base_dir, "Linux/frames")
        os.makedirs(frame_dir, exist_ok=True)

        env = os.environ.copy()
        env["DISPLAY"] = ":1"

        try:
            print(f"Running SLAM Command: {command} in {directory}")
            self.process = subprocess.Popen(
                command, shell=True, env=env, cwd=directory,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, preexec_fn=os.setsid
            )

            # Print real-time output from the process
            for line in self.process.stdout:
                print("SLAM Output:", line.strip())

            for line in self.process.stderr:
                print("SLAM Error:", line.strip())

            time.sleep(5)
            for _ in range(10):
                time.sleep(1)
                if self.move_window():
                    break
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)
            self.stop_button.set_sensitive(False)

    def on_show_features_clicked(self, widget):
        from features import Features
        self.set_keep_above(False)
        self.features_open = True
        subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id])

       
        feat = Features(self)
        feat.show_all()
        feat.set_keep_above(True)
    

    def move_window(self):
        try:
            print("Finding ORB-SLAM3: Map Viewer window...")
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True, check=True)
            print("wmctrl Output:", result.stdout)

            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:
                    self.viewer_window_id = window.split()[0]
                    print(f"Found Window ID: {self.viewer_window_id}")

                    subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
                                    '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'], check=True)
                    self.resize_and_position_viewer()
                    return True

            print("ORB-SLAM3 window not found.")
            return False
        except subprocess.CalledProcessError as e:
            print(f"Error moving window: {e}")
            return False

    def on_focus_in(self, widget, event):
            if self.viewer_window_id:
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
                self.resize_and_position_viewer()

            
            subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])

        # return

    def resize_and_position_viewer(self):
        if not self.viewer_window_id:
            print("Error: viewer_window_id is None. Cannot resize!")
            return

        try:
            app_x, app_y = self.get_position()
            width, height = self.get_size()
            available_width = width - self.fixed_button_width
            available_height = height

            print(f"Resizing window {self.viewer_window_id} to {available_width}x{available_height}")
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
                            '-e', f'0,{app_x},{app_y+47},{available_width},{available_height}'], check=True)
            subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Error resizing Map Viewer: {e}")

    def check_and_resize_map_viewer(self):
        if self.viewer_window_id:
            self.move_window()
            self.resize_and_position_viewer()

        if not self.logs_open or not self.features_open:
            print("Minimizing Map Viewer...")
            subprocess.run(['xdotool', 'windowminimize', self.viewer_window_id], capture_output=True, text=True)
        
        return True

    def create_header_bar(self):
        header_bar = Gtk.HeaderBar(title="Add New Map")
        header_bar.set_show_close_button(True)
        back_button = Gtk.Button(label="Back")
        back_button.connect("clicked", self.on_back_button_clicked)
        header_bar.pack_start(back_button)
        return header_bar

    def on_back_button_clicked(self, widget):
        if self.parent:
            self.parent.show_all()
            self.hide()
        else:
            self.connect("destroy",Gtk.main_quit)

    def on_stop_clicked(self, widget):
        if self.process:
            try:
                print("Stopping SLAM process...")
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)
                time.sleep(5)
                self.process.terminate()
                self.process.wait()
                self.process = None
                print("SLAM process stopped successfully.")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")

        self.close_map_viewer()
        self.start_button.set_sensitive(True)
        self.stop_button.set_sensitive(False)

    def close_map_viewer(self):
        if self.viewer_window_id:
            try:
                subprocess.run(['wmctrl', '-ic', self.viewer_window_id], check=True)
            except subprocess.CalledProcessError as e:
                print(f"Failed to close Map Viewer: {e}")
    


if __name__ == '__main__':
    debug=Debug_New_Map()
    # user=User_New_Map()
    debug.connect("destroy", Gtk.main_quit)
    # user.connect("destroy", Gtk.main_quit)
    debug.show_all()
    # user.show_all()
    Gtk.main()
    