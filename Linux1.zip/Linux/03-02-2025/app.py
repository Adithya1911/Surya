import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from add_map import Debug_New_Map, User_New_Map
from load_map import LoadMap



class Application(Gtk.Window):
    def __init__(self):
        super().__init__(title="Location Management")
        self.maximize()
        self.set_keep_above(True)
        self.set_titlebar(self.create_header_bar())

        # A flag to store the current mode
        self.debugger_mode = False

        # Main layout: Vertical box
        self.main_layout = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(self.main_layout)

        # Centering container
        self.center_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=20,
            margin=40
        )
        self.center_box.set_valign(Gtk.Align.CENTER)  # Center vertically
        self.center_box.set_halign(Gtk.Align.CENTER)   # Center horizontally
        self.main_layout.pack_start(self.center_box, True, True, 0)

        # Add 'Add Map' button
        add_location_button = Gtk.Button(label="Add Map")
        add_location_button.connect("clicked", self.on_add_location)
        self.center_box.pack_start(add_location_button, False, False, 0)

        # Add 'Load Map' button
        records_button = Gtk.Button(label="Load Map")
        records_button.connect("clicked", self.on_previous_records)
        self.center_box.pack_start(records_button, False, False, 0)

    def create_header_bar(self):
        """Creates a custom header bar with a Back button and a mode toggle button."""
        header_bar = Gtk.HeaderBar(title="Digital Heritage")
        header_bar.set_show_close_button(True)

        self.mode_toggle = Gtk.ToggleButton(label="User Mode")
        self.mode_toggle.connect("toggled", self.on_mode_toggle)
        header_bar.pack_end(self.mode_toggle)

        return header_bar

    def on_mode_toggle(self, toggle_button):
        """
        Called when the toggle is switched.
        If toggled on, request authentication for debugger mode.
        Otherwise, set the mode to default user.
        """
        if toggle_button.get_active():
            # User is attempting to switch to Debugger mode.
            if self.authenticate_debugger():
                self.debugger_mode = True
                toggle_button.set_label("Debugger Mode")
                print("Debugger mode activated.")
            else:
                # Authentication failed; revert the toggle and show error message.
                self.show_error_message("Authentication failed. Please check your credentials.")
                toggle_button.set_active(False)
                self.debugger_mode = False
                toggle_button.set_label("User Mode")
        else:
            # Revert to default user mode.
            self.debugger_mode = False
            toggle_button.set_label("User Mode")
            print("Switched to User mode.")

    def authenticate_debugger(self):
        """
        Displays an authentication dialog for debugger mode.
        Returns True if authentication is successful, otherwise False.
        """
        dialog = Gtk.Dialog(
            title="Debugger Authentication",
            transient_for=self,
            flags=0,
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        dialog.set_default_size(300, 150)

        grid = Gtk.Grid(margin=10, row_spacing=10, column_spacing=10)
        dialog.get_content_area().add(grid)

        username_label = Gtk.Label(label="Username:")
        grid.attach(username_label, 0, 0, 1, 1)
        username_entry = Gtk.Entry()
        grid.attach(username_entry, 1, 0, 1, 1)

        password_label = Gtk.Label(label="Password:")
        grid.attach(password_label, 0, 1, 1, 1)
        password_entry = Gtk.Entry()
        password_entry.set_visibility(False)
        grid.attach(password_entry, 1, 1, 1, 1)

        dialog.show_all()
        response = dialog.run()

        authenticated = False
        if response == Gtk.ResponseType.OK:
            username = username_entry.get_text()
            password = password_entry.get_text()
            # Replace the credentials below with your authentication logic.
            if username == "debug" and password == "pass":
                authenticated = True
            else:
                authenticated = False
        dialog.destroy()
        return authenticated

    def show_error_message(self, message):
        """
        Display an error message dialog to the user.
        """
        error_dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text="Authentication Error",
        )
        error_dialog.format_secondary_text(message)
        error_dialog.run()
        error_dialog.destroy()


    def on_add_location(self, button):
        """Action for adding a new location."""
        print("Add Map clicked.")
        self.set_keep_above(False)
        if self.debugger_mode:
            print('Debugger Live Action button is clicked')
            from add_map import Debug_New_Map
            self.hide()  # Hide the current window to prevent multiple windows from opening.
            new_map=Debug_New_Map(self)
            new_map.show_all()
            
        else:
            print('User Live Action button is clicked')
            from user import User_New_Map
            self.hide()  # Hide the current window to prevent multiple windows from opening.
            new_map=User_New_Map(self)
            new_map.show_all()
            

    def on_previous_records(self, button):
        """Action for viewing previous records."""
        print("Load Map clicked.")
        self.set_keep_above(False)
        if self.debugger_mode:
            print('Debugger Live Action button is clicked')
        else:
            print('User Live Action button is clicked')
        records_window = LoadMap(self)
        records_window.show_all()
        self.hide()
        

# Main program to run the Location Page
if __name__ == "__main__":
    win = Application()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
