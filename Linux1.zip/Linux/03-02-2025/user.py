import gi
import subprocess
import os
import time
from gi.repository import Gtk,GLib
gi.require_version("Gtk", "3.0")
import signal


class User_New_Map(Gtk.Window):
    def __init__(self,parent=None):
        Gtk.Window.__init__(self,title="User New Map")
        self.fullscreen()
        self.parent = parent
        self.main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(self.main_paned)
        self.fixed_button_width = 200 #The Button area is of Fixed Size
        self.apply_css()
        # Creating the Buttons on the Right Side of the Screen 
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.button_box.set_size_request(self.fixed_button_width, -1)
        self.main_paned.pack2(self.button_box, resize=False, shrink=False)

        # Start
        self.start_button = Gtk.Button(label="Start")
        self.start_button.set_margin_top(26) 
        self.start_button.set_halign(Gtk.Align.CENTER)
        self.start_button.set_valign(Gtk.Align.CENTER)
        self.start_button.connect("clicked", self.on_start_button_clicked)
        self.button_box.pack_start(self.start_button, False, False, 0)

        # Stop
        self.stop_button = Gtk.Button(label="Stop")
        self.stop_button.set_halign(Gtk.Align.CENTER)
        self.stop_button.set_valign(Gtk.Align.CENTER)
        self.stop_button.connect("clicked", self.on_stop_clicked)
        self.button_box.pack_start(self.stop_button, False, False, 0)

        # Back
        self.back_button = Gtk.Button(label="Back")
        self.back_button.set_halign(Gtk.Align.CENTER)
        self.back_button.set_valign(Gtk.Align.CENTER)
        self.back_button.connect("clicked", self.on_back_button_clicked)
        self.button_box.pack_end(self.back_button, False, False, 0)


        #Map Area
        
        self.map_area = Gtk.Label(label="The Slam Map is Viewed Here")
        self.map_area.set_size_request(794, 575)
        self.main_paned.pack1(self.map_area, resize=True, shrink=True)
        self.process = None
        self.viewer_window_id = None
        self.is_action_in_progress = False
        GLib.timeout_add_seconds(1, self.check_and_resize_map_viewer)
    
    def on_back_button_clicked(self,widget):
        if self.process:
            self.on_stop_clicked()
        if self.parent:
            self.parent.show_all()
            self.destroy()
        else:
            self.destroy()
            self.connect("destroy",Gtk.main_quit)
    
    def apply_css(self):
        # Load CSS file
        css_provider = Gtk.CssProvider()
        css_file_path = os.path.join(os.path.dirname(__file__), 'style.css')
        try:
            with open(css_file_path, 'r') as css_file:
                css_provider.load_from_data(css_file.read().encode('utf-8'))
            Gtk.StyleContext.add_provider_for_screen(
                Gtk.Window.get_screen(self), css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
        except Exception as e:
            print(f"Failed to apply CSS: {e}")

    def on_start_button_clicked(self, widget):
        self.start_button.set_sensitive(False)

        if self.process:
            self.process.terminate()
            self.process = None
        
        command = "./test_webcam_2.sh"
        current_dir = os.path.abspath(os.path.dirname(__file__))
        base_dir = os.path.abspath(os.path.join(current_dir, "../../"))
        directory = os.path.join(base_dir, "Examples/Monocular/Run_Scripts/")
        frame_dir = os.path.join(base_dir, "../frames")
        os.makedirs(frame_dir, exist_ok=True)

        env = os.environ.copy()
        env["DISPLAY"] = ":1"

        try:
            env = os.environ.copy()
            env["DISPLAY"] = ":1"

            self.process = subprocess.Popen(
                command, shell=True, env=env, cwd=directory, preexec_fn=os.setsid
            )
            time.sleep(5)
            for _ in range(10):
                time.sleep(1)
                if self.move_window():
                    break
        except Exception as e:
            print(f"Failed to start SLAM process: {e}")
            self.start_button.set_sensitive(True)
            
    def move_window(self):
        try:
            result = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True)
            windows = result.stdout.splitlines()
            for window in windows:
                if "ORB-SLAM3: Map Viewer" in window:
                    self.viewer_window_id = window.split()[0]
                    subprocess.run(['xprop', '-id', self.viewer_window_id, '-f', '_MOTIF_WM_HINTS', '32c',
                                    '-set', '_MOTIF_WM_HINTS', '0x2, 0x0, 0x0, 0x0, 0x0'])
                    self.resize_and_position_viewer()
                    return True
            return False
        except Exception as e:
            print(f"Error moving window: {e}")
            return False         
    
    # def on_focus_in(self, widget, event):
    #     if self.viewer_window_id:
    #         subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
    #         self.resize_and_position_viewer()

        
    #     subprocess.run(['xdotool', 'windowactivate', self.viewer_window_id])   
    
    def resize_and_position_viewer(self):
        if self.viewer_window_id:
            app_x, app_y = self.get_position()
            width, height = self.get_size()
            available_width = width - self.fixed_button_width
            available_height = height
            try:
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id,
                                '-e', f'0,{app_x},{app_y},{available_width},{available_height}'])
                subprocess.run(['wmctrl', '-i', '-r', self.viewer_window_id, '-b', 'add,above'])
            except Exception as e:
                print(f"Error resizing Map Viewer: {e}")
 
    def check_and_resize_map_viewer(self):
        if self.viewer_window_id:
            self.move_window()
            self.resize_and_position_viewer()
        return True
 
    def close_map_viewer(self):
        if self.viewer_window_id:
            try:
                subprocess.run(['wmctrl', '-ic', self.viewer_window_id])
            except Exception as e:
                print(f"Failed to close Map Viewer: {e}")   
    
    def create_header_bar(self):
        header_bar = Gtk.HeaderBar(title="Add New Map")
        header_bar.set_show_close_button(True)
        return header_bar
    
    def on_stop_clicked(self, widget):
        if self.process:
            try:
                print("Stopping SLAM process...")

                # Send SIGINT (equivalent to Ctrl+C)
                os.killpg(os.getpgid(self.process.pid), signal.SIGINT)

                # Wait a bit for the process to clean up and save the map
                time.sleep(5)  # Adjust this delay if needed

                # If the process is still running, force stop it
                self.process.terminate()
                self.process.wait()
                self.process = None

                print("SLAM process stopped successfully.")
            except Exception as e:
                print(f"Failed to stop SLAM process: {e}")

        self.close_map_viewer()
        self.start_button.set_sensitive(True)
        self.stop_button.set_sensitive(False)


if __name__=="__main__":
    app=User_New_Map()
    app.connect("destroy",Gtk.main_quit)
    app.show_all()
    Gtk.main()
    